using System;
using System.Collections.Generic;

namespace Btp.Hackathon.Core.Persistencia.Cargo 
{ 
    public class CargoItem : _BaseItem, Interface.Cargo.ICargoItem
    { 
        #region Propriedades 

        private string _connectionString { get; set; } 

        #endregion 

        #region Construtores 

        public CargoItem() 
            : this("") 
        { } 

        public CargoItem(string connectionString) 
        { 
            this._connectionString = connectionString; 
        } 

        #endregion 

        #region Métodos Públicos 

        public List<Entidade.Cargo.CargoItem> CarregarLista() 
        { 
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararSelecaoSql(null); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarLista<Entidade.Cargo.CargoItem>(databaseItem, sql, dicionario); 
        } 

        public Entidade.Cargo.CargoItem CarregarItem(int cargoId)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararSelecaoSql(cargoId); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            var retorno = base.CarregarItem<Entidade.Cargo.CargoItem>(databaseItem, sql, dicionario); 

            return retorno; 
        }

        public Entidade.Cargo.CargoItem InserirItem(Entidade.Cargo.CargoItem cargoItem)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            var sql = this.PrepararInsercaoSql(cargoItem); 

            sql += this.ObterUltimoItemInseridoSql();

            return base.CarregarItem<Entidade.Cargo.CargoItem>(databaseItem, sql, dicionario); 
        } 

        public Entidade.Cargo.CargoItem AtualizarItem(Entidade.Cargo.CargoItem cargoItem)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararAtualizacaoSql(cargoItem); 

            sql += this.PrepararSelecaoSql(cargoItem.Id);

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarItem<Entidade.Cargo.CargoItem>(databaseItem, sql, dicionario); 
        } 

        public Entidade.Cargo.CargoItem ExcluirItem(Entidade.Cargo.CargoItem cargoItem)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararExclusaoSql(cargoItem); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarItem<Entidade.Cargo.CargoItem>(databaseItem, sql, dicionario); 
        } 

        #endregion 

        #region Métodos Privados 

        private Dictionary<string, string> ObterDicionarioSelecaoSql()
        { 
            var dicionario = new Dictionary<string, string>(); 

            dicionario.Add("Id", "CARGO_ID"); 
            dicionario.Add("Nome", "NOME"); 

            return dicionario; 
        } 

        private string PrepararSelecaoSql()
        { 
            var sql = ""; 

            sql += "SELECT \n";
            sql += "    A.CARGO_ID,\n";
            sql += "    A.NOME\n";
            sql += "FROM \n";
            sql += "    CARGO_TB A\n";

            return sql; 
        } 

        private string PrepararSelecaoSql(int? cargoId)
		{ 
			var sql = ""; 

			if (cargoId.HasValue)
				sql += "A.CARGO_ID = " + cargoId.Value + "\n";

            if (!string.IsNullOrEmpty(sql))
            {
                sql = sql.Substring(0, sql.Length - 1);

                sql = sql.Replace("\n", "\nAND "); 

                sql = "WHERE\n\t" + sql; 
            } 

            sql = this.PrepararSelecaoSql() + " " + sql;

            return sql; 
        } 

        private string PrepararInsercaoSql(Entidade.Cargo.CargoItem cargoItem) 
        { 
            var sql = string.Empty; 

            sql += "INSERT INTO CARGO_TB(\n";
			sql += "    NOME,\n";

			sql = sql.Substring(0, sql.Length - 2) + "\n";

			sql += ") VALUES (\n";
			    sql += "    '" + cargoItem.Nome.Replace("'", "''") + "',\n";

			sql = sql.Substring(0, sql.Length - 2) + "\n";

            sql += ");\n";

            return sql; 
        } 

        private string PrepararAtualizacaoSql(Entidade.Cargo.CargoItem cargoItem) 
        { 
            var sql = string.Empty; 

            sql += "UPDATE \n";
            sql += "    A\n";
            sql += "SET\n";
			sql += "    A.NOME = '" + cargoItem.Nome.Replace("'", "''") + "',\n";

			sql = sql.Substring(0, sql.Length - 2) + "\n";

            sql += "FROM\n";
            sql += "    CARGO_TB A\n";
            sql += "WHERE\n";
            sql += "    A.CARGO_ID = " + cargoItem.Id + "\n";
            return sql; 
        } 

        private string PrepararExclusaoSql(Entidade.Cargo.CargoItem cargoItem) 
        { 
            var sql = string.Empty; 

            sql += "DELETE \n";
            sql += "    A\n";
            sql += "FROM\n";
            sql += "    CARGO_TB A\n";
            sql += "WHERE\n";
            sql += "    A.CARGO_ID = " + cargoItem.Id + "\n";
            return sql; 
        } 

        #endregion 
    
		#region Métodos Específicos do Banco

		private string ObterUltimoItemInseridoSql()
		{
			var sql = this.PrepararSelecaoSql();

			sql += "WHERE \n";

			sql += "    A.CARGO_ID = SCOPE_IDENTITY()\n";

			return sql;
		}

		#endregion
	}
}
