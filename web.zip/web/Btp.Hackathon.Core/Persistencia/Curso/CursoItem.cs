using System;
using System.Collections.Generic;

namespace Btp.Hackathon.Core.Persistencia.Curso 
{ 
    public class CursoItem : _BaseItem, Interface.Curso.ICursoItem
    { 
        #region Propriedades 

        private string _connectionString { get; set; } 

        #endregion 

        #region Construtores 

        public CursoItem() 
            : this("") 
        { } 

        public CursoItem(string connectionString) 
        { 
            this._connectionString = connectionString; 
        } 

        #endregion 

        #region Métodos Públicos 

        public List<Entidade.Curso.CursoItem> CarregarLista() 
        { 
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararSelecaoSql(null, null, null); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarLista<Entidade.Curso.CursoItem>(databaseItem, sql, dicionario); 
        } 

        public List<Entidade.Curso.CursoItem> CarregarListaPorDepartamentoId(int departamentoId) 
        { 
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararSelecaoSql(null, departamentoId, null); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarLista<Entidade.Curso.CursoItem>(databaseItem, sql, dicionario); 
        }

        public List<Entidade.Curso.CursoItem> CarregarListaPorFuncionarioId(int funcionarioId)
        {
            var databaseItem = new Btp.Database.DatabaseItem();

            var sql = this.PrepararSelecaoSql(null, null, funcionarioId);

            var dicionario = this.ObterDicionarioSelecaoSql();

            return base.CarregarLista<Entidade.Curso.CursoItem>(databaseItem, sql, dicionario);
        }

        public Entidade.Curso.CursoItem CarregarItem(int cursoId)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararSelecaoSql(cursoId, null, null); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            var retorno = base.CarregarItem<Entidade.Curso.CursoItem>(databaseItem, sql, dicionario); 

            return retorno; 
        }

        public Entidade.Curso.CursoItem InserirItem(Entidade.Curso.CursoItem cursoItem)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            var sql = this.PrepararInsercaoSql(cursoItem); 

            sql += this.ObterUltimoItemInseridoSql();

            return base.CarregarItem<Entidade.Curso.CursoItem>(databaseItem, sql, dicionario); 
        } 

        public Entidade.Curso.CursoItem AtualizarItem(Entidade.Curso.CursoItem cursoItem)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararAtualizacaoSql(cursoItem); 

            sql += this.PrepararSelecaoSql(cursoItem.Id, null, null);

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarItem<Entidade.Curso.CursoItem>(databaseItem, sql, dicionario); 
        } 

        public Entidade.Curso.CursoItem ExcluirItem(Entidade.Curso.CursoItem cursoItem)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararExclusaoSql(cursoItem); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarItem<Entidade.Curso.CursoItem>(databaseItem, sql, dicionario); 
        } 

        #endregion 

        #region Métodos Privados 

        private Dictionary<string, string> ObterDicionarioSelecaoSql()
        { 
            var dicionario = new Dictionary<string, string>(); 

            dicionario.Add("Id", "CURSO_ID"); 
            dicionario.Add("DepartamentoId", "DEPARTAMENTO_ID"); 
            dicionario.Add("Nome", "NOME"); 
            dicionario.Add("Descricao", "DESCRICAO"); 

            return dicionario; 
        } 

        private string PrepararSelecaoSql()
        { 
            var sql = ""; 

            sql += "SELECT DISTINCT \n";
            sql += "    A.CURSO_ID,\n";
            sql += "    A.DEPARTAMENTO_ID,\n";
            sql += "    A.NOME,\n";
            sql += "    A.DESCRICAO\n";
            sql += "FROM \n";
            sql += "    CURSO_TB A\n";
            sql += "    INNER JOIN CURSO_MODULO_TB B ON B.CURSO_ID = A.CURSO_ID\n";
            sql += "    LEFT JOIN CURSO_MODULO_ACESSO_TB C ON C.CURSO_MODULO_ID = B.CURSO_MODULO_ID\n";

            return sql; 
        } 

        private string PrepararSelecaoSql(int? cursoId, int? departamentoId, int? funcionarioId)
		{ 
			var sql = ""; 

			if (cursoId.HasValue)
				sql += "A.CURSO_ID = " + cursoId.Value + "\n";

			if (departamentoId.HasValue)
				sql += "A.DEPARTAMENTO_ID = " + departamentoId.Value + "\n";

            if (funcionarioId.HasValue)
                sql += "C.FUNCIONARIO_ID = " + funcionarioId.Value + "\n";

            if (!string.IsNullOrEmpty(sql))
            {
                sql = sql.Substring(0, sql.Length - 1);

                sql = sql.Replace("\n", "\nAND "); 

                sql = "WHERE\n\t" + sql; 
            } 

            sql = this.PrepararSelecaoSql() + " " + sql;

            return sql; 
        } 

        private string PrepararInsercaoSql(Entidade.Curso.CursoItem cursoItem) 
        { 
            var sql = string.Empty; 

            sql += "INSERT INTO CURSO_TB(\n";
			sql += "    DEPARTAMENTO_ID,\n";

			sql += "    NOME,\n";

			sql += "    DESCRICAO,\n";

			sql = sql.Substring(0, sql.Length - 2) + "\n";

			sql += ") VALUES (\n";
			sql += "    " + cursoItem.DepartamentoId.ToString() + ",\n";

			    sql += "    '" + cursoItem.Nome.Replace("'", "''") + "',\n";

			    sql += "    '" + cursoItem.Descricao.Replace("'", "''") + "',\n";

			sql = sql.Substring(0, sql.Length - 2) + "\n";

            sql += ");\n";

            return sql; 
        } 

        private string PrepararAtualizacaoSql(Entidade.Curso.CursoItem cursoItem) 
        { 
            var sql = string.Empty; 

            sql += "UPDATE \n";
            sql += "    A\n";
            sql += "SET\n";
			sql += "    A.DEPARTAMENTO_ID = " + cursoItem.DepartamentoId.ToString() + ",\n"; 

			sql += "    A.NOME = '" + cursoItem.Nome.Replace("'", "''") + "',\n";

			sql += "    A.DESCRICAO = '" + cursoItem.Descricao.Replace("'", "''") + "',\n";

			sql = sql.Substring(0, sql.Length - 2) + "\n";

            sql += "FROM\n";
            sql += "    CURSO_TB A\n";
            sql += "WHERE\n";
            sql += "    A.CURSO_ID = " + cursoItem.Id + "\n";
            return sql; 
        } 

        private string PrepararExclusaoSql(Entidade.Curso.CursoItem cursoItem) 
        { 
            var sql = string.Empty; 

            sql += "DELETE \n";
            sql += "    A\n";
            sql += "FROM\n";
            sql += "    CURSO_TB A\n";
            sql += "WHERE\n";
            sql += "    A.CURSO_ID = " + cursoItem.Id + "\n";
            return sql; 
        } 

        #endregion 
    
		#region Métodos Específicos do Banco

		private string ObterUltimoItemInseridoSql()
		{
			var sql = this.PrepararSelecaoSql();

			sql += "WHERE \n";

			sql += "    A.CURSO_ID = SCOPE_IDENTITY()\n";

			return sql;
		}

		#endregion
	}
}
