using System;
using System.Collections.Generic;

namespace Btp.Hackathon.Core.Persistencia.Curso.Prioridade 
{ 
    public class PrioridadeItem : _BaseItem, Interface.Curso.Prioridade.IPrioridadeItem
    { 
        #region Propriedades 

        private string _connectionString { get; set; } 

        #endregion 

        #region Construtores 

        public PrioridadeItem() 
            : this("") 
        { } 

        public PrioridadeItem(string connectionString) 
        { 
            this._connectionString = connectionString; 
        } 

        #endregion 

        #region Métodos Públicos 

        public List<Entidade.Curso.Prioridade.PrioridadeItem> CarregarLista() 
        { 
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararSelecaoSql(null); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarLista<Entidade.Curso.Prioridade.PrioridadeItem>(databaseItem, sql, dicionario); 
        } 

        public Entidade.Curso.Prioridade.PrioridadeItem CarregarItem(int cursoPrioridadeId)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararSelecaoSql(cursoPrioridadeId); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            var retorno = base.CarregarItem<Entidade.Curso.Prioridade.PrioridadeItem>(databaseItem, sql, dicionario); 

            return retorno; 
        }

        public Entidade.Curso.Prioridade.PrioridadeItem InserirItem(Entidade.Curso.Prioridade.PrioridadeItem prioridadeItem)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            var sql = this.PrepararInsercaoSql(prioridadeItem); 

            sql += this.ObterUltimoItemInseridoSql();

            return base.CarregarItem<Entidade.Curso.Prioridade.PrioridadeItem>(databaseItem, sql, dicionario); 
        } 

        public Entidade.Curso.Prioridade.PrioridadeItem AtualizarItem(Entidade.Curso.Prioridade.PrioridadeItem prioridadeItem)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararAtualizacaoSql(prioridadeItem); 

            sql += this.PrepararSelecaoSql(prioridadeItem.Id);

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarItem<Entidade.Curso.Prioridade.PrioridadeItem>(databaseItem, sql, dicionario); 
        } 

        public Entidade.Curso.Prioridade.PrioridadeItem ExcluirItem(Entidade.Curso.Prioridade.PrioridadeItem prioridadeItem)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararExclusaoSql(prioridadeItem); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarItem<Entidade.Curso.Prioridade.PrioridadeItem>(databaseItem, sql, dicionario); 
        } 

        #endregion 

        #region Métodos Privados 

        private Dictionary<string, string> ObterDicionarioSelecaoSql()
        { 
            var dicionario = new Dictionary<string, string>(); 

            dicionario.Add("Id", "CURSO_PRIORIDADE_ID"); 
            dicionario.Add("Nome", "NOME"); 

            return dicionario; 
        } 

        private string PrepararSelecaoSql()
        { 
            var sql = ""; 

            sql += "SELECT \n";
            sql += "    A.CURSO_PRIORIDADE_ID,\n";
            sql += "    A.NOME\n";
            sql += "FROM \n";
            sql += "    CURSO_PRIORIDADE_TB A\n";

            return sql; 
        } 

        private string PrepararSelecaoSql(int? cursoPrioridadeId)
		{ 
			var sql = ""; 

			if (cursoPrioridadeId.HasValue)
				sql += "A.CURSO_PRIORIDADE_ID = " + cursoPrioridadeId.Value + "\n";

            if (!string.IsNullOrEmpty(sql))
            {
                sql = sql.Substring(0, sql.Length - 1);

                sql = sql.Replace("\n", "\nAND "); 

                sql = "WHERE\n\t" + sql; 
            } 

            sql = this.PrepararSelecaoSql() + " " + sql;

            return sql; 
        } 

        private string PrepararInsercaoSql(Entidade.Curso.Prioridade.PrioridadeItem prioridadeItem) 
        { 
            var sql = string.Empty; 

            sql += "INSERT INTO CURSO_PRIORIDADE_TB(\n";
			sql += "    NOME,\n";

			sql = sql.Substring(0, sql.Length - 2) + "\n";

			sql += ") VALUES (\n";
			    sql += "    '" + prioridadeItem.Nome.Replace("'", "''") + "',\n";

			sql = sql.Substring(0, sql.Length - 2) + "\n";

            sql += ");\n";

            return sql; 
        } 

        private string PrepararAtualizacaoSql(Entidade.Curso.Prioridade.PrioridadeItem prioridadeItem) 
        { 
            var sql = string.Empty; 

            sql += "UPDATE \n";
            sql += "    A\n";
            sql += "SET\n";
			sql += "    A.NOME = '" + prioridadeItem.Nome.Replace("'", "''") + "',\n";

			sql = sql.Substring(0, sql.Length - 2) + "\n";

            sql += "FROM\n";
            sql += "    CURSO_PRIORIDADE_TB A\n";
            sql += "WHERE\n";
            sql += "    A.CURSO_PRIORIDADE_ID = " + prioridadeItem.Id + "\n";
            return sql; 
        } 

        private string PrepararExclusaoSql(Entidade.Curso.Prioridade.PrioridadeItem prioridadeItem) 
        { 
            var sql = string.Empty; 

            sql += "DELETE \n";
            sql += "    A\n";
            sql += "FROM\n";
            sql += "    CURSO_PRIORIDADE_TB A\n";
            sql += "WHERE\n";
            sql += "    A.CURSO_PRIORIDADE_ID = " + prioridadeItem.Id + "\n";
            return sql; 
        } 

        #endregion 
    
		#region Métodos Específicos do Banco

		private string ObterUltimoItemInseridoSql()
		{
			var sql = this.PrepararSelecaoSql();

			sql += "WHERE \n";

			sql += "    A.CURSO_PRIORIDADE_ID = SCOPE_IDENTITY()\n";

			return sql;
		}

		#endregion
	}
}
