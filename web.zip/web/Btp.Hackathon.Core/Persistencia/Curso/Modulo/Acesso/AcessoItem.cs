using System;
using System.Collections.Generic;

namespace Btp.Hackathon.Core.Persistencia.Curso.Modulo.Acesso 
{ 
    public class AcessoItem : _BaseItem, Interface.Curso.Modulo.Acesso.IAcessoItem
    { 
        #region Propriedades 

        private string _connectionString { get; set; } 

        #endregion 

        #region Construtores 

        public AcessoItem() 
            : this("") 
        { } 

        public AcessoItem(string connectionString) 
        { 
            this._connectionString = connectionString; 
        } 

        #endregion 

        #region Métodos Públicos 

        public List<Entidade.Curso.Modulo.Acesso.AcessoItem> CarregarLista() 
        { 
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararSelecaoSql(null, null); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarLista<Entidade.Curso.Modulo.Acesso.AcessoItem>(databaseItem, sql, dicionario); 
        } 
        
        public List<Entidade.Curso.Modulo.Acesso.AcessoItem> CarregarListaPorFuncionarioId(int funcionarioId) 
        { 
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararSelecaoSql(null, funcionarioId); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarLista<Entidade.Curso.Modulo.Acesso.AcessoItem>(databaseItem, sql, dicionario); 
        } 

        public Entidade.Curso.Modulo.Acesso.AcessoItem CarregarItem(int cursoModuloAcessoId)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararSelecaoSql(cursoModuloAcessoId, null); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            var retorno = base.CarregarItem<Entidade.Curso.Modulo.Acesso.AcessoItem>(databaseItem, sql, dicionario); 

            return retorno; 
        }

        public Entidade.Curso.Modulo.Acesso.AcessoItem InserirItem(Entidade.Curso.Modulo.Acesso.AcessoItem acessoItem)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            var sql = this.PrepararInsercaoSql(acessoItem); 

            sql += this.ObterUltimoItemInseridoSql();

            return base.CarregarItem<Entidade.Curso.Modulo.Acesso.AcessoItem>(databaseItem, sql, dicionario); 
        } 

        public Entidade.Curso.Modulo.Acesso.AcessoItem AtualizarItem(Entidade.Curso.Modulo.Acesso.AcessoItem acessoItem)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararAtualizacaoSql(acessoItem); 

            sql += this.PrepararSelecaoSql(acessoItem.Id, null);

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarItem<Entidade.Curso.Modulo.Acesso.AcessoItem>(databaseItem, sql, dicionario); 
        } 

        public Entidade.Curso.Modulo.Acesso.AcessoItem ExcluirItem(Entidade.Curso.Modulo.Acesso.AcessoItem acessoItem)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararExclusaoSql(acessoItem); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarItem<Entidade.Curso.Modulo.Acesso.AcessoItem>(databaseItem, sql, dicionario); 
        } 

        #endregion 

        #region Métodos Privados 

        private Dictionary<string, string> ObterDicionarioSelecaoSql()
        { 
            var dicionario = new Dictionary<string, string>(); 

            dicionario.Add("Id", "CURSO_MODULO_ACESSO_ID"); 
            dicionario.Add("CursoModuloId", "CURSO_MODULO_ID"); 
            dicionario.Add("FuncionarioId", "FUNCIONARIO_ID"); 
            dicionario.Add("DataInicial", "DATA_INICIAL"); 
            dicionario.Add("DataFinal", "DATA_FINAL"); 

            return dicionario; 
        } 

        private string PrepararSelecaoSql()
        { 
            var sql = ""; 

            sql += "SELECT \n";
            sql += "    A.CURSO_MODULO_ACESSO_ID,\n";
            sql += "    A.CURSO_MODULO_ID,\n";
            sql += "    A.FUNCIONARIO_ID,\n";
            sql += "    A.DATA_INICIAL,\n";
            sql += "    A.DATA_FINAL\n";
            sql += "FROM \n";
            sql += "    CURSO_MODULO_ACESSO_TB A\n";

            return sql; 
        } 

        private string PrepararSelecaoSql(int? cursoModuloAcessoId, int? funcionarioId)
		{ 
			var sql = ""; 

			if (cursoModuloAcessoId.HasValue)
				sql += "A.CURSO_MODULO_ACESSO_ID = " + cursoModuloAcessoId.Value + "\n";
            
			if (funcionarioId.HasValue)
				sql += "A.FUNCIONARIO_ID = " + funcionarioId.Value + "\n";

            if (!string.IsNullOrEmpty(sql))
            {
                sql = sql.Substring(0, sql.Length - 1);

                sql = sql.Replace("\n", "\nAND "); 

                sql = "WHERE\n\t" + sql; 
            } 

            sql = this.PrepararSelecaoSql() + " " + sql;

            return sql; 
        } 

        private string PrepararInsercaoSql(Entidade.Curso.Modulo.Acesso.AcessoItem acessoItem) 
        { 
            var sql = string.Empty; 

            sql += "INSERT INTO CURSO_MODULO_ACESSO_TB(\n";
			sql += "    CURSO_MODULO_ID,\n";

			sql += "    FUNCIONARIO_ID,\n";

			sql += "    DATA_INICIAL,\n";

			if (acessoItem.DataFinal > DateTime.MinValue)
				sql += "    DATA_FINAL,\n";

			sql = sql.Substring(0, sql.Length - 2) + "\n";

			sql += ") VALUES (\n";
			sql += "    " + acessoItem.CursoModuloId.ToString() + ",\n";

			sql += "    " + acessoItem.FuncionarioId.ToString() + ",\n";

			sql += "    '" + string.Format("{0:yyyy-MM-dd HH:mm:ss}", acessoItem.DataInicial) + "',\n";

			if (acessoItem.DataFinal > DateTime.MinValue)
				sql += "    '" + string.Format("{0:yyyy-MM-dd HH:mm:ss}", acessoItem.DataFinal) + "',\n";

			sql = sql.Substring(0, sql.Length - 2) + "\n";

            sql += ");\n";

            return sql; 
        } 

        private string PrepararAtualizacaoSql(Entidade.Curso.Modulo.Acesso.AcessoItem acessoItem) 
        { 
            var sql = string.Empty; 

            sql += "UPDATE \n";
            sql += "    A\n";
            sql += "SET\n";
			sql += "    A.CURSO_MODULO_ID = " + acessoItem.CursoModuloId.ToString() + ",\n"; 

			sql += "    A.FUNCIONARIO_ID = " + acessoItem.FuncionarioId.ToString() + ",\n"; 

			sql += "    A.DATA_INICIAL = '" + string.Format("{0:yyyy-MM-dd HH:mm:ss}", acessoItem.DataInicial) + "',\n"; 

			if (acessoItem.DataFinal > DateTime.MinValue)
				sql += "    A.DATA_FINAL = '" + string.Format("{0:yyyy-MM-dd HH:mm:ss}", acessoItem.DataFinal) + "',\n"; 

			sql = sql.Substring(0, sql.Length - 2) + "\n";

            sql += "FROM\n";
            sql += "    CURSO_MODULO_ACESSO_TB A\n";
            sql += "WHERE\n";
            sql += "    A.CURSO_MODULO_ACESSO_ID = " + acessoItem.Id + "\n";
            return sql; 
        } 

        private string PrepararExclusaoSql(Entidade.Curso.Modulo.Acesso.AcessoItem acessoItem) 
        { 
            var sql = string.Empty; 

            sql += "DELETE \n";
            sql += "    A\n";
            sql += "FROM\n";
            sql += "    CURSO_MODULO_ACESSO_TB A\n";
            sql += "WHERE\n";
            sql += "    A.CURSO_MODULO_ACESSO_ID = " + acessoItem.Id + "\n";
            return sql; 
        } 

        #endregion 
    
		#region Métodos Específicos do Banco

		private string ObterUltimoItemInseridoSql()
		{
			var sql = this.PrepararSelecaoSql();

			sql += "WHERE \n";

			sql += "    A.CURSO_MODULO_ACESSO_ID = SCOPE_IDENTITY()\n";

			return sql;
		}

		#endregion
	}
}
