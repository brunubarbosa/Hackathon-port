using System;
using System.Collections.Generic;

namespace Btp.Hackathon.Core.Persistencia.Curso.Modulo.Etapa 
{ 
    public class EtapaItem : _BaseItem, Interface.Curso.Modulo.Etapa.IEtapaItem
    { 
        #region Propriedades 

        private string _connectionString { get; set; } 

        #endregion 

        #region Construtores 

        public EtapaItem() 
            : this("") 
        { } 

        public EtapaItem(string connectionString) 
        { 
            this._connectionString = connectionString; 
        } 

        #endregion 

        #region Métodos Públicos 

        public List<Entidade.Curso.Modulo.Etapa.EtapaItem> CarregarLista() 
        { 
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararSelecaoSql(null); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarLista<Entidade.Curso.Modulo.Etapa.EtapaItem>(databaseItem, sql, dicionario); 
        } 

        public Entidade.Curso.Modulo.Etapa.EtapaItem CarregarItem(int cursoModuloEtapaId)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararSelecaoSql(cursoModuloEtapaId); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            var retorno = base.CarregarItem<Entidade.Curso.Modulo.Etapa.EtapaItem>(databaseItem, sql, dicionario); 

            return retorno; 
        }

        public Entidade.Curso.Modulo.Etapa.EtapaItem InserirItem(Entidade.Curso.Modulo.Etapa.EtapaItem etapaItem)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            var sql = this.PrepararInsercaoSql(etapaItem); 

            sql += this.ObterUltimoItemInseridoSql();

            return base.CarregarItem<Entidade.Curso.Modulo.Etapa.EtapaItem>(databaseItem, sql, dicionario); 
        } 

        public Entidade.Curso.Modulo.Etapa.EtapaItem AtualizarItem(Entidade.Curso.Modulo.Etapa.EtapaItem etapaItem)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararAtualizacaoSql(etapaItem); 

            sql += this.PrepararSelecaoSql(etapaItem.Id);

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarItem<Entidade.Curso.Modulo.Etapa.EtapaItem>(databaseItem, sql, dicionario); 
        } 

        public Entidade.Curso.Modulo.Etapa.EtapaItem ExcluirItem(Entidade.Curso.Modulo.Etapa.EtapaItem etapaItem)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararExclusaoSql(etapaItem); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarItem<Entidade.Curso.Modulo.Etapa.EtapaItem>(databaseItem, sql, dicionario); 
        } 

        #endregion 

        #region Métodos Privados 

        private Dictionary<string, string> ObterDicionarioSelecaoSql()
        { 
            var dicionario = new Dictionary<string, string>(); 

            dicionario.Add("Id", "CURSO_MODULO_ETAPA_ID"); 
            dicionario.Add("HoraQuantidade", "HORA_QUANTIDADE"); 
            dicionario.Add("Titulo", "TITULO"); 
            dicionario.Add("Descricao", "DESCRICAO"); 

            return dicionario; 
        } 

        private string PrepararSelecaoSql()
        { 
            var sql = ""; 

            sql += "SELECT \n";
            sql += "    A.CURSO_MODULO_ETAPA_ID,\n";
            sql += "    A.HORA_QUANTIDADE,\n";
            sql += "    A.TITULO,\n";
            sql += "    A.DESCRICAO\n";
            sql += "FROM \n";
            sql += "    CURSO_MODULO_ETAPA_TB A\n";

            return sql; 
        } 

        private string PrepararSelecaoSql(int? cursoModuloEtapaId)
		{ 
			var sql = ""; 

			if (cursoModuloEtapaId.HasValue)
				sql += "A.CURSO_MODULO_ETAPA_ID = " + cursoModuloEtapaId.Value + "\n";

            if (!string.IsNullOrEmpty(sql))
            {
                sql = sql.Substring(0, sql.Length - 1);

                sql = sql.Replace("\n", "\nAND "); 

                sql = "WHERE\n\t" + sql; 
            } 

            sql = this.PrepararSelecaoSql() + " " + sql;

            return sql; 
        } 

        private string PrepararInsercaoSql(Entidade.Curso.Modulo.Etapa.EtapaItem etapaItem) 
        { 
            var sql = string.Empty; 

            sql += "INSERT INTO CURSO_MODULO_ETAPA_TB(\n";
			sql += "    HORA_QUANTIDADE,\n";

			sql += "    TITULO,\n";

			sql += "    DESCRICAO,\n";

			sql = sql.Substring(0, sql.Length - 2) + "\n";

			sql += ") VALUES (\n";
			sql += "    " + etapaItem.HoraQuantidade.ToString() + ",\n";

			    sql += "    '" + etapaItem.Titulo.Replace("'", "''") + "',\n";

			    sql += "    '" + etapaItem.Descricao.Replace("'", "''") + "',\n";

			sql = sql.Substring(0, sql.Length - 2) + "\n";

            sql += ");\n";

            return sql; 
        } 

        private string PrepararAtualizacaoSql(Entidade.Curso.Modulo.Etapa.EtapaItem etapaItem) 
        { 
            var sql = string.Empty; 

            sql += "UPDATE \n";
            sql += "    A\n";
            sql += "SET\n";
			sql += "    A.HORA_QUANTIDADE = " + etapaItem.HoraQuantidade.ToString() + ",\n"; 

			sql += "    A.TITULO = '" + etapaItem.Titulo.Replace("'", "''") + "',\n";

			sql += "    A.DESCRICAO = '" + etapaItem.Descricao.Replace("'", "''") + "',\n";

			sql = sql.Substring(0, sql.Length - 2) + "\n";

            sql += "FROM\n";
            sql += "    CURSO_MODULO_ETAPA_TB A\n";
            sql += "WHERE\n";
            sql += "    A.CURSO_MODULO_ETAPA_ID = " + etapaItem.Id + "\n";
            return sql; 
        } 

        private string PrepararExclusaoSql(Entidade.Curso.Modulo.Etapa.EtapaItem etapaItem) 
        { 
            var sql = string.Empty; 

            sql += "DELETE \n";
            sql += "    A\n";
            sql += "FROM\n";
            sql += "    CURSO_MODULO_ETAPA_TB A\n";
            sql += "WHERE\n";
            sql += "    A.CURSO_MODULO_ETAPA_ID = " + etapaItem.Id + "\n";
            return sql; 
        } 

        #endregion 
    
		#region Métodos Específicos do Banco

		private string ObterUltimoItemInseridoSql()
		{
			var sql = this.PrepararSelecaoSql();

			sql += "WHERE \n";

			sql += "    A.CURSO_MODULO_ETAPA_ID = SCOPE_IDENTITY()\n";

			return sql;
		}

		#endregion
	}
}
