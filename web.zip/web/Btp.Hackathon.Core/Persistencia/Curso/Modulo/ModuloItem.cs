using System;
using System.Collections.Generic;

namespace Btp.Hackathon.Core.Persistencia.Curso.Modulo 
{ 
    public class ModuloItem : _BaseItem, Interface.Curso.Modulo.IModuloItem
    { 
        #region Propriedades 

        private string _connectionString { get; set; } 

        #endregion 

        #region Construtores 

        public ModuloItem() 
            : this("") 
        { } 

        public ModuloItem(string connectionString) 
        { 
            this._connectionString = connectionString; 
        } 

        #endregion 

        #region Métodos Públicos 

        public List<Entidade.Curso.Modulo.ModuloItem> CarregarLista() 
        { 
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararSelecaoSql(null, null); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarLista<Entidade.Curso.Modulo.ModuloItem>(databaseItem, sql, dicionario); 
        } 

        public List<Entidade.Curso.Modulo.ModuloItem> CarregarListaPorCursoId(int cursoId) 
        { 
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararSelecaoSql(null, cursoId); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarLista<Entidade.Curso.Modulo.ModuloItem>(databaseItem, sql, dicionario); 
        } 

        public Entidade.Curso.Modulo.ModuloItem CarregarItem(int cursoModuloId)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararSelecaoSql(cursoModuloId, null); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            var retorno = base.CarregarItem<Entidade.Curso.Modulo.ModuloItem>(databaseItem, sql, dicionario); 

            return retorno; 
        }

        public Entidade.Curso.Modulo.ModuloItem InserirItem(Entidade.Curso.Modulo.ModuloItem moduloItem)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            var sql = this.PrepararInsercaoSql(moduloItem); 

            sql += this.ObterUltimoItemInseridoSql();

            return base.CarregarItem<Entidade.Curso.Modulo.ModuloItem>(databaseItem, sql, dicionario); 
        } 

        public Entidade.Curso.Modulo.ModuloItem AtualizarItem(Entidade.Curso.Modulo.ModuloItem moduloItem)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararAtualizacaoSql(moduloItem); 

            sql += this.PrepararSelecaoSql(moduloItem.Id, null);

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarItem<Entidade.Curso.Modulo.ModuloItem>(databaseItem, sql, dicionario); 
        } 

        public Entidade.Curso.Modulo.ModuloItem ExcluirItem(Entidade.Curso.Modulo.ModuloItem moduloItem)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararExclusaoSql(moduloItem); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarItem<Entidade.Curso.Modulo.ModuloItem>(databaseItem, sql, dicionario); 
        } 

        #endregion 

        #region Métodos Privados 

        private Dictionary<string, string> ObterDicionarioSelecaoSql()
        { 
            var dicionario = new Dictionary<string, string>(); 

            dicionario.Add("Id", "CURSO_MODULO_ID"); 
            dicionario.Add("CursoId", "CURSO_ID"); 
            dicionario.Add("HoraQuantidade", "HORA_QUANTIDADE"); 
            dicionario.Add("PontoQuantidade", "PONTO_QUANTIDADE"); 
            dicionario.Add("Titulo", "TITULO"); 
            dicionario.Add("Descricao", "DESCRICAO"); 

            return dicionario; 
        } 

        private string PrepararSelecaoSql()
        { 
            var sql = ""; 

            sql += "SELECT \n";
            sql += "    A.CURSO_MODULO_ID,\n";
            sql += "    A.CURSO_ID,\n";
            sql += "    A.HORA_QUANTIDADE,\n";
            sql += "    A.PONTO_QUANTIDADE,\n";
            sql += "    A.TITULO,\n";
            sql += "    A.DESCRICAO\n";
            sql += "FROM \n";
            sql += "    CURSO_MODULO_TB A\n";

            return sql; 
        } 

        private string PrepararSelecaoSql(int? cursoModuloId, int? cursoId)
		{ 
			var sql = ""; 

			if (cursoModuloId.HasValue)
				sql += "A.CURSO_MODULO_ID = " + cursoModuloId.Value + "\n";

			if (cursoId.HasValue)
				sql += "A.CURSO_ID = " + cursoId.Value + "\n";

            if (!string.IsNullOrEmpty(sql))
            {
                sql = sql.Substring(0, sql.Length - 1);

                sql = sql.Replace("\n", "\nAND "); 

                sql = "WHERE\n\t" + sql; 
            } 

            sql = this.PrepararSelecaoSql() + " " + sql;

            return sql; 
        } 

        private string PrepararInsercaoSql(Entidade.Curso.Modulo.ModuloItem moduloItem) 
        { 
            var sql = string.Empty; 

            sql += "INSERT INTO CURSO_MODULO_TB(\n";
			sql += "    CURSO_ID,\n";

			sql += "    HORA_QUANTIDADE,\n";

			sql += "    PONTO_QUANTIDADE,\n";

			sql += "    TITULO,\n";

			sql += "    DESCRICAO,\n";

			sql = sql.Substring(0, sql.Length - 2) + "\n";

			sql += ") VALUES (\n";
			sql += "    " + moduloItem.CursoId.ToString() + ",\n";

			sql += "    " + moduloItem.HoraQuantidade.ToString() + ",\n";

			sql += "    " + moduloItem.PontoQuantidade.ToString() + ",\n";

			    sql += "    '" + moduloItem.Titulo.Replace("'", "''") + "',\n";

			    sql += "    '" + moduloItem.Descricao.Replace("'", "''") + "',\n";

			sql = sql.Substring(0, sql.Length - 2) + "\n";

            sql += ");\n";

            return sql; 
        } 

        private string PrepararAtualizacaoSql(Entidade.Curso.Modulo.ModuloItem moduloItem) 
        { 
            var sql = string.Empty; 

            sql += "UPDATE \n";
            sql += "    A\n";
            sql += "SET\n";
			sql += "    A.CURSO_ID = " + moduloItem.CursoId.ToString() + ",\n"; 

			sql += "    A.HORA_QUANTIDADE = " + moduloItem.HoraQuantidade.ToString() + ",\n"; 

			sql += "    A.PONTO_QUANTIDADE = " + moduloItem.PontoQuantidade.ToString() + ",\n"; 

			sql += "    A.TITULO = '" + moduloItem.Titulo.Replace("'", "''") + "',\n";

			sql += "    A.DESCRICAO = '" + moduloItem.Descricao.Replace("'", "''") + "',\n";

			sql = sql.Substring(0, sql.Length - 2) + "\n";

            sql += "FROM\n";
            sql += "    CURSO_MODULO_TB A\n";
            sql += "WHERE\n";
            sql += "    A.CURSO_MODULO_ID = " + moduloItem.Id + "\n";
            return sql; 
        } 

        private string PrepararExclusaoSql(Entidade.Curso.Modulo.ModuloItem moduloItem) 
        { 
            var sql = string.Empty; 

            sql += "DELETE \n";
            sql += "    A\n";
            sql += "FROM\n";
            sql += "    CURSO_MODULO_TB A\n";
            sql += "WHERE\n";
            sql += "    A.CURSO_MODULO_ID = " + moduloItem.Id + "\n";
            return sql; 
        } 

        #endregion 
    
		#region Métodos Específicos do Banco

		private string ObterUltimoItemInseridoSql()
		{
			var sql = this.PrepararSelecaoSql();

			sql += "WHERE \n";

			sql += "    A.CURSO_MODULO_ID = SCOPE_IDENTITY()\n";

			return sql;
		}

		#endregion
	}
}
