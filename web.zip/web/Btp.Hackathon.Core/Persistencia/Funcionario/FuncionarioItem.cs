using System;
using System.Collections.Generic;

namespace Btp.Hackathon.Core.Persistencia.Funcionario 
{ 
    public class FuncionarioItem : _BaseItem, Interface.Funcionario.IFuncionarioItem
    { 
        #region Propriedades 

        private string _connectionString { get; set; } 

        #endregion 

        #region Construtores 

        public FuncionarioItem() 
            : this("") 
        { } 

        public FuncionarioItem(string connectionString) 
        { 
            this._connectionString = connectionString; 
        } 

        #endregion 

        #region Métodos Públicos 

        public List<Entidade.Funcionario.FuncionarioItem> CarregarLista() 
        { 
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararSelecaoSql(null, null, null, null); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarLista<Entidade.Funcionario.FuncionarioItem>(databaseItem, sql, dicionario); 
        } 

        public List<Entidade.Funcionario.FuncionarioItem> CarregarListaPorDepartamentoId(int departamentoId) 
        { 
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararSelecaoSql(null, departamentoId, null, null); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarLista<Entidade.Funcionario.FuncionarioItem>(databaseItem, sql, dicionario); 
        }

        public List<Entidade.Funcionario.FuncionarioItem> CarregarListaPorNavioId(int navioId)
        {
            var databaseItem = new Btp.Database.DatabaseItem();

            var sql = this.PrepararSelecaoSql(null, null, null, navioId);

            var dicionario = this.ObterDicionarioSelecaoSql();

            return base.CarregarLista<Entidade.Funcionario.FuncionarioItem>(databaseItem, sql, dicionario);
        }

        public List<Entidade.Funcionario.FuncionarioItem> CarregarListaPorCargoId(int cargoId) 
        { 
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararSelecaoSql(null, null, cargoId, null); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarLista<Entidade.Funcionario.FuncionarioItem>(databaseItem, sql, dicionario); 
        } 

        public Entidade.Funcionario.FuncionarioItem CarregarItem(int funcionarioId)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararSelecaoSql(funcionarioId, null, null, null); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            var retorno = base.CarregarItem<Entidade.Funcionario.FuncionarioItem>(databaseItem, sql, dicionario); 

            return retorno; 
        }

        public Entidade.Funcionario.FuncionarioItem InserirItem(Entidade.Funcionario.FuncionarioItem funcionarioItem)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            var sql = this.PrepararInsercaoSql(funcionarioItem); 

            sql += this.ObterUltimoItemInseridoSql();

            return base.CarregarItem<Entidade.Funcionario.FuncionarioItem>(databaseItem, sql, dicionario); 
        } 

        public Entidade.Funcionario.FuncionarioItem AtualizarItem(Entidade.Funcionario.FuncionarioItem funcionarioItem)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararAtualizacaoSql(funcionarioItem); 

            sql += this.PrepararSelecaoSql(funcionarioItem.Id, null, null, null);

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarItem<Entidade.Funcionario.FuncionarioItem>(databaseItem, sql, dicionario); 
        } 

        public Entidade.Funcionario.FuncionarioItem ExcluirItem(Entidade.Funcionario.FuncionarioItem funcionarioItem)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararExclusaoSql(funcionarioItem); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarItem<Entidade.Funcionario.FuncionarioItem>(databaseItem, sql, dicionario); 
        } 

        #endregion 

        #region Métodos Privados 

        private Dictionary<string, string> ObterDicionarioSelecaoSql()
        { 
            var dicionario = new Dictionary<string, string>(); 

            dicionario.Add("Id", "FUNCIONARIO_ID"); 
            dicionario.Add("DepartamentoId", "DEPARTAMENTO_ID"); 
            dicionario.Add("CargoId", "CARGO_ID"); 
            dicionario.Add("Codigo", "CODIGO"); 
            dicionario.Add("Nome", "NOME");
            dicionario.Add("DepartamentoNome", "DEPARTAMENTO_NOME");
            dicionario.Add("CargoNome", "CARGO_NOME");
            dicionario.Add("ArquivoFotoUrl", "ARQUIVO_FOTO_URL");

            return dicionario; 
        } 

        private string PrepararSelecaoSql()
        { 
            var sql = ""; 

            sql += "SELECT DISTINCT \n";
            sql += "    A.FUNCIONARIO_ID,\n";
            sql += "    A.DEPARTAMENTO_ID,\n";
            sql += "    A.CARGO_ID,\n";
            sql += "    A.CODIGO,\n";
            sql += "    A.NOME,\n";
            sql += "    A.ARQUIVO_FOTO_URL,\n";
            sql += "    B.NOME AS DEPARTAMENTO_NOME,\n";
            sql += "    C.NOME AS CARGO_NOME\n";
            sql += "FROM \n";
            sql += "    FUNCIONARIO_TB A\n";
            sql += "    INNER JOIN DEPARTAMENTO_TB B ON B.DEPARTAMENTO_ID = A.DEPARTAMENTO_ID\n";
            sql += "    INNER JOIN CARGO_TB C ON C.CARGO_ID = A.CARGO_ID\n";
            sql += "    INNER JOIN NAVIO_FUNCIONARIO_TB D ON D.FUNCIONARIO_ID = A.FUNCIONARIO_ID\n";

            return sql; 
        } 

        private string PrepararSelecaoSql(int? funcionarioId, int? departamentoId, int? cargoId, int? navioId)
		{ 
			var sql = ""; 

			if (funcionarioId.HasValue)
				sql += "A.FUNCIONARIO_ID = " + funcionarioId.Value + "\n";

			if (departamentoId.HasValue)
				sql += "A.DEPARTAMENTO_ID = " + departamentoId.Value + "\n";

			if (cargoId.HasValue)
				sql += "A.CARGO_ID = " + cargoId.Value + "\n";

            if (navioId.HasValue)
                sql += "D.NAVIO_ID = " + navioId.Value + "\n";

            if (!string.IsNullOrEmpty(sql))
            {
                sql = sql.Substring(0, sql.Length - 1);

                sql = sql.Replace("\n", "\nAND "); 

                sql = "WHERE\n\t" + sql; 
            } 

            sql = this.PrepararSelecaoSql() + " " + sql;

            return sql; 
        } 

        private string PrepararInsercaoSql(Entidade.Funcionario.FuncionarioItem funcionarioItem) 
        { 
            var sql = string.Empty; 

            sql += "INSERT INTO FUNCIONARIO_TB(\n";
			sql += "    DEPARTAMENTO_ID,\n";

			sql += "    CARGO_ID,\n";

			sql += "    CODIGO,\n";

			sql += "    NOME,\n";

			sql = sql.Substring(0, sql.Length - 2) + "\n";

			sql += ") VALUES (\n";
			sql += "    " + funcionarioItem.DepartamentoId.ToString() + ",\n";

			sql += "    " + funcionarioItem.CargoId.ToString() + ",\n";

			    sql += "    '" + funcionarioItem.Codigo.Replace("'", "''") + "',\n";

			    sql += "    '" + funcionarioItem.Nome.Replace("'", "''") + "',\n";

			sql = sql.Substring(0, sql.Length - 2) + "\n";

            sql += ");\n";

            return sql; 
        } 

        private string PrepararAtualizacaoSql(Entidade.Funcionario.FuncionarioItem funcionarioItem) 
        { 
            var sql = string.Empty; 

            sql += "UPDATE \n";
            sql += "    A\n";
            sql += "SET\n";
			sql += "    A.DEPARTAMENTO_ID = " + funcionarioItem.DepartamentoId.ToString() + ",\n"; 

			sql += "    A.CARGO_ID = " + funcionarioItem.CargoId.ToString() + ",\n"; 

			sql += "    A.CODIGO = '" + funcionarioItem.Codigo.Replace("'", "''") + "',\n";

			sql += "    A.NOME = '" + funcionarioItem.Nome.Replace("'", "''") + "',\n";

			sql = sql.Substring(0, sql.Length - 2) + "\n";

            sql += "FROM\n";
            sql += "    FUNCIONARIO_TB A\n";
            sql += "WHERE\n";
            sql += "    A.FUNCIONARIO_ID = " + funcionarioItem.Id + "\n";
            return sql; 
        } 

        private string PrepararExclusaoSql(Entidade.Funcionario.FuncionarioItem funcionarioItem) 
        { 
            var sql = string.Empty; 

            sql += "DELETE \n";
            sql += "    A\n";
            sql += "FROM\n";
            sql += "    FUNCIONARIO_TB A\n";
            sql += "WHERE\n";
            sql += "    A.FUNCIONARIO_ID = " + funcionarioItem.Id + "\n";
            return sql; 
        } 

        #endregion 
    
		#region Métodos Específicos do Banco

		private string ObterUltimoItemInseridoSql()
		{
			var sql = this.PrepararSelecaoSql();

			sql += "WHERE \n";

			sql += "    A.FUNCIONARIO_ID = SCOPE_IDENTITY()\n";

			return sql;
		}

		#endregion
	}
}
