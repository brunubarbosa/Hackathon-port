using System;
using System.Collections.Generic;

namespace Btp.Hackathon.Core.Persistencia.Navio 
{ 
    public class NavioItem : _BaseItem, Interface.Navio.INavioItem
    { 
        #region Propriedades 

        private string _connectionString { get; set; } 

        #endregion 

        #region Construtores 

        public NavioItem() 
            : this("") 
        { } 

        public NavioItem(string connectionString) 
        { 
            this._connectionString = connectionString; 
        } 

        #endregion 

        #region Métodos Públicos 

        public List<Entidade.Navio.NavioItem> CarregarLista() 
        { 
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararSelecaoSql(null, null); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarLista<Entidade.Navio.NavioItem>(databaseItem, sql, dicionario); 
        } 

        public List<Entidade.Navio.NavioItem> CarregarListaPorNavioSituacaoId(int navioSituacaoId) 
        { 
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararSelecaoSql(null, navioSituacaoId); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarLista<Entidade.Navio.NavioItem>(databaseItem, sql, dicionario); 
        } 

        public Entidade.Navio.NavioItem CarregarItem(int navioId)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararSelecaoSql(navioId, null); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            var retorno = base.CarregarItem<Entidade.Navio.NavioItem>(databaseItem, sql, dicionario); 

            return retorno; 
        }

        public Entidade.Navio.NavioItem InserirItem(Entidade.Navio.NavioItem navioItem)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            var sql = this.PrepararInsercaoSql(navioItem); 

            sql += this.ObterUltimoItemInseridoSql();

            return base.CarregarItem<Entidade.Navio.NavioItem>(databaseItem, sql, dicionario); 
        } 

        public Entidade.Navio.NavioItem AtualizarItem(Entidade.Navio.NavioItem navioItem)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararAtualizacaoSql(navioItem); 

            sql += this.PrepararSelecaoSql(navioItem.Id, null);

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarItem<Entidade.Navio.NavioItem>(databaseItem, sql, dicionario); 
        } 

        public Entidade.Navio.NavioItem ExcluirItem(Entidade.Navio.NavioItem navioItem)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararExclusaoSql(navioItem); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarItem<Entidade.Navio.NavioItem>(databaseItem, sql, dicionario); 
        } 

        #endregion 

        #region Métodos Privados 

        private Dictionary<string, string> ObterDicionarioSelecaoSql()
        { 
            var dicionario = new Dictionary<string, string>(); 

            dicionario.Add("Id", "NAVIO_ID"); 
            dicionario.Add("NavioSituacaoId", "NAVIO_SITUACAO_ID"); 
            dicionario.Add("Nome", "NOME"); 
            dicionario.Add("ContainerQuantidade", "CONTAINER_QUANTIDADE"); 
            dicionario.Add("DataPrevisaoChegada", "DATA_PREVISAO_CHEGADA"); 
            dicionario.Add("DataPrevisaoAtracacao", "DATA_PREVISAO_ATRACACAO"); 
            dicionario.Add("DataPrevisaoDesatracacao", "DATA_PREVISAO_DESATRACACAO"); 
            dicionario.Add("DataPrevisaoSaida", "DATA_PREVISAO_SAIDA"); 
            dicionario.Add("DataEfetivaChegada", "DATA_EFETIVA_CHEGADA"); 
            dicionario.Add("DataEfetivaAtracacao", "DATA_EFETIVA_ATRACACAO"); 
            dicionario.Add("DataEfetivaDesatracacao", "DATA_EFETIVA_DESATRACACAO"); 
            dicionario.Add("DataEfetivaSaida", "DATA_EFETIVA_SAIDA"); 
            dicionario.Add("ArquivoFotoUrl", "ARQUIVO_FOTO_URL");
            dicionario.Add("NavioSituacaoNome", "NAVIO_SITUACAO_NOME");

            return dicionario; 
        } 

        private string PrepararSelecaoSql()
        { 
            var sql = ""; 

            sql += "SELECT \n";
            sql += "    A.NAVIO_ID,\n";
            sql += "    A.NAVIO_SITUACAO_ID,\n";
            sql += "    A.NOME,\n";
            sql += "    A.CONTAINER_QUANTIDADE,\n";
            sql += "    A.DATA_PREVISAO_CHEGADA,\n";
            sql += "    A.DATA_PREVISAO_ATRACACAO,\n";
            sql += "    A.DATA_PREVISAO_DESATRACACAO,\n";
            sql += "    A.DATA_PREVISAO_SAIDA,\n";
            sql += "    A.DATA_EFETIVA_CHEGADA,\n";
            sql += "    A.DATA_EFETIVA_ATRACACAO,\n";
            sql += "    A.DATA_EFETIVA_DESATRACACAO,\n";
            sql += "    A.DATA_EFETIVA_SAIDA,\n";
            sql += "    A.ARQUIVO_FOTO_URL,\n";
            sql += "    B.NOME AS NAVIO_SITUACAO_NOME\n";
            sql += "FROM \n";
            sql += "    NAVIO_TB A\n";
            sql += "    INNER JOIN NAVIO_SITUACAO_TB B ON B.NAVIO_SITUACAO_ID = A.NAVIO_SITUACAO_ID\n";

            return sql; 
        } 

        private string PrepararSelecaoSql(int? navioId, int? navioSituacaoId)
		{ 
			var sql = ""; 

			if (navioId.HasValue)
				sql += "A.NAVIO_ID = " + navioId.Value + "\n";

			if (navioSituacaoId.HasValue)
				sql += "A.NAVIO_SITUACAO_ID = " + navioSituacaoId.Value + "\n";

            if (!string.IsNullOrEmpty(sql))
            {
                sql = sql.Substring(0, sql.Length - 1);

                sql = sql.Replace("\n", "\nAND "); 

                sql = "WHERE\n\t" + sql; 
            } 

            sql = this.PrepararSelecaoSql() + " " + sql;

            return sql; 
        } 

        private string PrepararInsercaoSql(Entidade.Navio.NavioItem navioItem) 
        { 
            var sql = string.Empty; 

            sql += "INSERT INTO NAVIO_TB(\n";
			sql += "    NAVIO_SITUACAO_ID,\n";

			sql += "    NOME,\n";

			sql += "    CONTAINER_QUANTIDADE,\n";

			if (navioItem.DataPrevisaoChegada > DateTime.MinValue)
				sql += "    DATA_PREVISAO_CHEGADA,\n";

			if (navioItem.DataPrevisaoAtracacao > DateTime.MinValue)
				sql += "    DATA_PREVISAO_ATRACACAO,\n";

			if (navioItem.DataPrevisaoDesatracacao > DateTime.MinValue)
				sql += "    DATA_PREVISAO_DESATRACACAO,\n";

			if (navioItem.DataPrevisaoSaida > DateTime.MinValue)
				sql += "    DATA_PREVISAO_SAIDA,\n";

			if (navioItem.DataEfetivaChegada > DateTime.MinValue)
				sql += "    DATA_EFETIVA_CHEGADA,\n";

			if (navioItem.DataEfetivaAtracacao > DateTime.MinValue)
				sql += "    DATA_EFETIVA_ATRACACAO,\n";

			if (navioItem.DataEfetivaDesatracacao > DateTime.MinValue)
				sql += "    DATA_EFETIVA_DESATRACACAO,\n";

			if (navioItem.DataEfetivaSaida > DateTime.MinValue)
				sql += "    DATA_EFETIVA_SAIDA,\n";

			sql += "    ARQUIVO_FOTO_URL,\n";

			sql = sql.Substring(0, sql.Length - 2) + "\n";

			sql += ") VALUES (\n";
			sql += "    " + navioItem.NavioSituacaoId.ToString() + ",\n";

			    sql += "    '" + navioItem.Nome.Replace("'", "''") + "',\n";

			sql += "    " + navioItem.ContainerQuantidade.ToString() + ",\n";

			if (navioItem.DataPrevisaoChegada > DateTime.MinValue)
				sql += "    '" + string.Format("{0:yyyy-MM-dd HH:mm:ss}", navioItem.DataPrevisaoChegada) + "',\n";

			if (navioItem.DataPrevisaoAtracacao > DateTime.MinValue)
				sql += "    '" + string.Format("{0:yyyy-MM-dd HH:mm:ss}", navioItem.DataPrevisaoAtracacao) + "',\n";

			if (navioItem.DataPrevisaoDesatracacao > DateTime.MinValue)
				sql += "    '" + string.Format("{0:yyyy-MM-dd HH:mm:ss}", navioItem.DataPrevisaoDesatracacao) + "',\n";

			if (navioItem.DataPrevisaoSaida > DateTime.MinValue)
				sql += "    '" + string.Format("{0:yyyy-MM-dd HH:mm:ss}", navioItem.DataPrevisaoSaida) + "',\n";

			if (navioItem.DataEfetivaChegada > DateTime.MinValue)
				sql += "    '" + string.Format("{0:yyyy-MM-dd HH:mm:ss}", navioItem.DataEfetivaChegada) + "',\n";

			if (navioItem.DataEfetivaAtracacao > DateTime.MinValue)
				sql += "    '" + string.Format("{0:yyyy-MM-dd HH:mm:ss}", navioItem.DataEfetivaAtracacao) + "',\n";

			if (navioItem.DataEfetivaDesatracacao > DateTime.MinValue)
				sql += "    '" + string.Format("{0:yyyy-MM-dd HH:mm:ss}", navioItem.DataEfetivaDesatracacao) + "',\n";

			if (navioItem.DataEfetivaSaida > DateTime.MinValue)
				sql += "    '" + string.Format("{0:yyyy-MM-dd HH:mm:ss}", navioItem.DataEfetivaSaida) + "',\n";

			if (string.IsNullOrEmpty(navioItem.ArquivoFotoUrl))
			    sql += "    NULL,\n";
			else
			    sql += "    '" + navioItem.ArquivoFotoUrl.Replace("'", "''") + "',\n";

			sql = sql.Substring(0, sql.Length - 2) + "\n";

            sql += ");\n";

            return sql; 
        } 

        private string PrepararAtualizacaoSql(Entidade.Navio.NavioItem navioItem) 
        { 
            var sql = string.Empty; 

            sql += "UPDATE \n";
            sql += "    A\n";
            sql += "SET\n";
			sql += "    A.NAVIO_SITUACAO_ID = " + navioItem.NavioSituacaoId.ToString() + ",\n"; 

			sql += "    A.NOME = '" + navioItem.Nome.Replace("'", "''") + "',\n";

			sql += "    A.CONTAINER_QUANTIDADE = " + navioItem.ContainerQuantidade.ToString() + ",\n"; 

			if (navioItem.DataPrevisaoChegada > DateTime.MinValue)
				sql += "    A.DATA_PREVISAO_CHEGADA = '" + string.Format("{0:yyyy-MM-dd HH:mm:ss}", navioItem.DataPrevisaoChegada) + "',\n"; 

			if (navioItem.DataPrevisaoAtracacao > DateTime.MinValue)
				sql += "    A.DATA_PREVISAO_ATRACACAO = '" + string.Format("{0:yyyy-MM-dd HH:mm:ss}", navioItem.DataPrevisaoAtracacao) + "',\n"; 

			if (navioItem.DataPrevisaoDesatracacao > DateTime.MinValue)
				sql += "    A.DATA_PREVISAO_DESATRACACAO = '" + string.Format("{0:yyyy-MM-dd HH:mm:ss}", navioItem.DataPrevisaoDesatracacao) + "',\n"; 

			if (navioItem.DataPrevisaoSaida > DateTime.MinValue)
				sql += "    A.DATA_PREVISAO_SAIDA = '" + string.Format("{0:yyyy-MM-dd HH:mm:ss}", navioItem.DataPrevisaoSaida) + "',\n"; 

			if (navioItem.DataEfetivaChegada > DateTime.MinValue)
				sql += "    A.DATA_EFETIVA_CHEGADA = '" + string.Format("{0:yyyy-MM-dd HH:mm:ss}", navioItem.DataEfetivaChegada) + "',\n"; 

			if (navioItem.DataEfetivaAtracacao > DateTime.MinValue)
				sql += "    A.DATA_EFETIVA_ATRACACAO = '" + string.Format("{0:yyyy-MM-dd HH:mm:ss}", navioItem.DataEfetivaAtracacao) + "',\n"; 

			if (navioItem.DataEfetivaDesatracacao > DateTime.MinValue)
				sql += "    A.DATA_EFETIVA_DESATRACACAO = '" + string.Format("{0:yyyy-MM-dd HH:mm:ss}", navioItem.DataEfetivaDesatracacao) + "',\n"; 

			if (navioItem.DataEfetivaSaida > DateTime.MinValue)
				sql += "    A.DATA_EFETIVA_SAIDA = '" + string.Format("{0:yyyy-MM-dd HH:mm:ss}", navioItem.DataEfetivaSaida) + "',\n"; 

			if (string.IsNullOrEmpty(navioItem.ArquivoFotoUrl))
			    sql += "    A.ARQUIVO_FOTO_URL = NULL,\n";
			else
				sql += "    A.ARQUIVO_FOTO_URL = '" + navioItem.ArquivoFotoUrl.Replace("'", "''") + "',\n";

			sql = sql.Substring(0, sql.Length - 2) + "\n";

            sql += "FROM\n";
            sql += "    NAVIO_TB A\n";
            sql += "WHERE\n";
            sql += "    A.NAVIO_ID = " + navioItem.Id + "\n";
            return sql; 
        } 

        private string PrepararExclusaoSql(Entidade.Navio.NavioItem navioItem) 
        { 
            var sql = string.Empty; 

            sql += "DELETE \n";
            sql += "    A\n";
            sql += "FROM\n";
            sql += "    NAVIO_TB A\n";
            sql += "WHERE\n";
            sql += "    A.NAVIO_ID = " + navioItem.Id + "\n";
            return sql; 
        } 

        #endregion 
    
		#region Métodos Específicos do Banco

		private string ObterUltimoItemInseridoSql()
		{
			var sql = this.PrepararSelecaoSql();

			sql += "WHERE \n";

			sql += "    A.NAVIO_ID = SCOPE_IDENTITY()\n";

			return sql;
		}

		#endregion
	}
}
