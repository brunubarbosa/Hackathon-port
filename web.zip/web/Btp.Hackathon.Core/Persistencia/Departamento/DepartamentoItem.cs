using System;
using System.Collections.Generic;

namespace Btp.Hackathon.Core.Persistencia.Departamento 
{ 
    public class DepartamentoItem : _BaseItem, Interface.Departamento.IDepartamentoItem
    { 
        #region Propriedades 

        private string _connectionString { get; set; } 

        #endregion 

        #region Construtores 

        public DepartamentoItem() 
            : this("") 
        { } 

        public DepartamentoItem(string connectionString) 
        { 
            this._connectionString = connectionString; 
        } 

        #endregion 

        #region Métodos Públicos 

        public List<Entidade.Departamento.DepartamentoItem> CarregarLista() 
        { 
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararSelecaoSql(null); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarLista<Entidade.Departamento.DepartamentoItem>(databaseItem, sql, dicionario); 
        } 

        public Entidade.Departamento.DepartamentoItem CarregarItem(int departamentoId)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararSelecaoSql(departamentoId); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            var retorno = base.CarregarItem<Entidade.Departamento.DepartamentoItem>(databaseItem, sql, dicionario); 

            return retorno; 
        }

        public Entidade.Departamento.DepartamentoItem InserirItem(Entidade.Departamento.DepartamentoItem departamentoItem)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            var sql = this.PrepararInsercaoSql(departamentoItem); 

            sql += this.ObterUltimoItemInseridoSql();

            return base.CarregarItem<Entidade.Departamento.DepartamentoItem>(databaseItem, sql, dicionario); 
        } 

        public Entidade.Departamento.DepartamentoItem AtualizarItem(Entidade.Departamento.DepartamentoItem departamentoItem)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararAtualizacaoSql(departamentoItem); 

            sql += this.PrepararSelecaoSql(departamentoItem.Id);

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarItem<Entidade.Departamento.DepartamentoItem>(databaseItem, sql, dicionario); 
        } 

        public Entidade.Departamento.DepartamentoItem ExcluirItem(Entidade.Departamento.DepartamentoItem departamentoItem)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararExclusaoSql(departamentoItem); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarItem<Entidade.Departamento.DepartamentoItem>(databaseItem, sql, dicionario); 
        } 

        #endregion 

        #region Métodos Privados 

        private Dictionary<string, string> ObterDicionarioSelecaoSql()
        { 
            var dicionario = new Dictionary<string, string>(); 

            dicionario.Add("Id", "DEPARTAMENTO_ID"); 
            dicionario.Add("Nome", "NOME"); 

            return dicionario; 
        } 

        private string PrepararSelecaoSql()
        { 
            var sql = ""; 

            sql += "SELECT \n";
            sql += "    A.DEPARTAMENTO_ID,\n";
            sql += "    A.NOME\n";
            sql += "FROM \n";
            sql += "    DEPARTAMENTO_TB A\n";

            return sql; 
        } 

        private string PrepararSelecaoSql(int? departamentoId)
		{ 
			var sql = ""; 

			if (departamentoId.HasValue)
				sql += "A.DEPARTAMENTO_ID = " + departamentoId.Value + "\n";

            if (!string.IsNullOrEmpty(sql))
            {
                sql = sql.Substring(0, sql.Length - 1);

                sql = sql.Replace("\n", "\nAND "); 

                sql = "WHERE\n\t" + sql; 
            } 

            sql = this.PrepararSelecaoSql() + " " + sql;

            return sql; 
        } 

        private string PrepararInsercaoSql(Entidade.Departamento.DepartamentoItem departamentoItem) 
        { 
            var sql = string.Empty; 

            sql += "INSERT INTO DEPARTAMENTO_TB(\n";
			sql += "    NOME,\n";

			sql = sql.Substring(0, sql.Length - 2) + "\n";

			sql += ") VALUES (\n";
			    sql += "    '" + departamentoItem.Nome.Replace("'", "''") + "',\n";

			sql = sql.Substring(0, sql.Length - 2) + "\n";

            sql += ");\n";

            return sql; 
        } 

        private string PrepararAtualizacaoSql(Entidade.Departamento.DepartamentoItem departamentoItem) 
        { 
            var sql = string.Empty; 

            sql += "UPDATE \n";
            sql += "    A\n";
            sql += "SET\n";
			sql += "    A.NOME = '" + departamentoItem.Nome.Replace("'", "''") + "',\n";

			sql = sql.Substring(0, sql.Length - 2) + "\n";

            sql += "FROM\n";
            sql += "    DEPARTAMENTO_TB A\n";
            sql += "WHERE\n";
            sql += "    A.DEPARTAMENTO_ID = " + departamentoItem.Id + "\n";
            return sql; 
        } 

        private string PrepararExclusaoSql(Entidade.Departamento.DepartamentoItem departamentoItem) 
        { 
            var sql = string.Empty; 

            sql += "DELETE \n";
            sql += "    A\n";
            sql += "FROM\n";
            sql += "    DEPARTAMENTO_TB A\n";
            sql += "WHERE\n";
            sql += "    A.DEPARTAMENTO_ID = " + departamentoItem.Id + "\n";
            return sql; 
        } 

        #endregion 
    
		#region Métodos Específicos do Banco

		private string ObterUltimoItemInseridoSql()
		{
			var sql = this.PrepararSelecaoSql();

			sql += "WHERE \n";

			sql += "    A.DEPARTAMENTO_ID = SCOPE_IDENTITY()\n";

			return sql;
		}

		#endregion
	}
}
