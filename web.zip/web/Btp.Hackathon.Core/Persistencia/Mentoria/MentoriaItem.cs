using System;
using System.Collections.Generic;

namespace Btp.Hackathon.Core.Persistencia.Mentoria 
{ 
    public class MentoriaItem : _BaseItem, Interface.Mentoria.IMentoriaItem
    { 
        #region Propriedades 

        private string _connectionString { get; set; } 

        #endregion 

        #region Construtores 

        public MentoriaItem() 
            : this("") 
        { } 

        public MentoriaItem(string connectionString) 
        { 
            this._connectionString = connectionString; 
        } 

        #endregion 

        #region Métodos Públicos 

        public List<Entidade.Mentoria.MentoriaItem> CarregarLista() 
        { 
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararSelecaoSql(null, null, null); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarLista<Entidade.Mentoria.MentoriaItem>(databaseItem, sql, dicionario); 
        } 

        public List<Entidade.Mentoria.MentoriaItem> CarregarListaPorDepartamentoId(int departamentoId) 
        { 
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararSelecaoSql(null, departamentoId, null); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarLista<Entidade.Mentoria.MentoriaItem>(databaseItem, sql, dicionario); 
        } 

        public List<Entidade.Mentoria.MentoriaItem> CarregarListaPorFuncionarioId(int funcionarioId) 
        { 
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararSelecaoSql(null, null, funcionarioId); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarLista<Entidade.Mentoria.MentoriaItem>(databaseItem, sql, dicionario); 
        } 

        public Entidade.Mentoria.MentoriaItem CarregarItem(int mentoriaId)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararSelecaoSql(mentoriaId, null, null); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            var retorno = base.CarregarItem<Entidade.Mentoria.MentoriaItem>(databaseItem, sql, dicionario); 

            return retorno; 
        }

        public Entidade.Mentoria.MentoriaItem InserirItem(Entidade.Mentoria.MentoriaItem mentoriaItem)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            var sql = this.PrepararInsercaoSql(mentoriaItem); 

            sql += this.ObterUltimoItemInseridoSql();

            return base.CarregarItem<Entidade.Mentoria.MentoriaItem>(databaseItem, sql, dicionario); 
        } 

        public Entidade.Mentoria.MentoriaItem AtualizarItem(Entidade.Mentoria.MentoriaItem mentoriaItem)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararAtualizacaoSql(mentoriaItem); 

            sql += this.PrepararSelecaoSql(mentoriaItem.Id, null, null);

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarItem<Entidade.Mentoria.MentoriaItem>(databaseItem, sql, dicionario); 
        } 

        public Entidade.Mentoria.MentoriaItem ExcluirItem(Entidade.Mentoria.MentoriaItem mentoriaItem)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararExclusaoSql(mentoriaItem); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarItem<Entidade.Mentoria.MentoriaItem>(databaseItem, sql, dicionario); 
        } 

        #endregion 

        #region Métodos Privados 

        private Dictionary<string, string> ObterDicionarioSelecaoSql()
        { 
            var dicionario = new Dictionary<string, string>(); 

            dicionario.Add("Id", "MENTORIA_ID"); 
            dicionario.Add("DepartamentoId", "DEPARTAMENTO_ID"); 
            dicionario.Add("FuncionarioId", "FUNCIONARIO_ID");
            dicionario.Add("DepartamentoNome", "DEPARTAMENTO_NOME");
            dicionario.Add("FuncionarioNome", "FUNCIONARIO_NOME");
            dicionario.Add("DataInclusao", "DATA_INCLUSAO"); 
            dicionario.Add("DataValidade", "DATA_VALIDADE"); 

            return dicionario; 
        } 

        private string PrepararSelecaoSql()
        { 
            var sql = ""; 

            sql += "SELECT \n";
            sql += "    A.MENTORIA_ID,\n";
            sql += "    A.DEPARTAMENTO_ID,\n";
            sql += "    A.FUNCIONARIO_ID,\n";
            sql += "    B.NOME AS DEPARTAMENTO_NOME,\n";
            sql += "    C.NOME AS FUNCIONARIO_NOME,\n";
            sql += "    A.DATA_INCLUSAO,\n";
            sql += "    A.DATA_VALIDADE\n";
            sql += "FROM \n";
            sql += "    MENTORIA_TB A\n";
            sql += "    INNER JOIN DEPARTAMENTO_TB B ON B.DEPARTAMENTO_ID = A.DEPARTAMENTO_ID\n";
            sql += "    INNER JOIN FUNCIONARIO_TB C ON C.FUNCIONARIO_ID = A.FUNCIONARIO_ID\n";

            return sql; 
        } 

        private string PrepararSelecaoSql(int? mentoriaId, int? departamentoId, int? funcionarioId)
		{ 
			var sql = ""; 

			if (mentoriaId.HasValue)
				sql += "A.MENTORIA_ID = " + mentoriaId.Value + "\n";

			if (departamentoId.HasValue)
				sql += "A.DEPARTAMENTO_ID = " + departamentoId.Value + "\n";

			if (funcionarioId.HasValue)
				sql += "A.FUNCIONARIO_ID = " + funcionarioId.Value + "\n";

            if (!string.IsNullOrEmpty(sql))
            {
                sql = sql.Substring(0, sql.Length - 1);

                sql = sql.Replace("\n", "\nAND "); 

                sql = "WHERE\n\t" + sql; 
            } 

            sql = this.PrepararSelecaoSql() + " " + sql;

            return sql; 
        } 

        private string PrepararInsercaoSql(Entidade.Mentoria.MentoriaItem mentoriaItem) 
        { 
            var sql = string.Empty; 

            sql += "INSERT INTO MENTORIA_TB(\n";
			sql += "    DEPARTAMENTO_ID,\n";

			sql += "    FUNCIONARIO_ID,\n";

			sql += "    DATA_VALIDADE,\n";

			sql = sql.Substring(0, sql.Length - 2) + "\n";

			sql += ") VALUES (\n";
			sql += "    " + mentoriaItem.DepartamentoId.ToString() + ",\n";

			sql += "    " + mentoriaItem.FuncionarioId.ToString() + ",\n";

			sql += "    '" + string.Format("{0:yyyy-MM-dd HH:mm:ss}", mentoriaItem.DataValidade) + "',\n";

			sql = sql.Substring(0, sql.Length - 2) + "\n";

            sql += ");\n";

            return sql; 
        } 

        private string PrepararAtualizacaoSql(Entidade.Mentoria.MentoriaItem mentoriaItem) 
        { 
            var sql = string.Empty; 

            sql += "UPDATE \n";
            sql += "    A\n";
            sql += "SET\n";
			sql += "    A.DEPARTAMENTO_ID = " + mentoriaItem.DepartamentoId.ToString() + ",\n"; 

			sql += "    A.FUNCIONARIO_ID = " + mentoriaItem.FuncionarioId.ToString() + ",\n"; 

			sql += "    A.DATA_VALIDADE = '" + string.Format("{0:yyyy-MM-dd HH:mm:ss}", mentoriaItem.DataValidade) + "',\n"; 

			sql = sql.Substring(0, sql.Length - 2) + "\n";

            sql += "FROM\n";
            sql += "    MENTORIA_TB A\n";
            sql += "WHERE\n";
            sql += "    A.MENTORIA_ID = " + mentoriaItem.Id + "\n";
            return sql; 
        } 

        private string PrepararExclusaoSql(Entidade.Mentoria.MentoriaItem mentoriaItem) 
        { 
            var sql = string.Empty; 

            sql += "DELETE \n";
            sql += "    A\n";
            sql += "FROM\n";
            sql += "    MENTORIA_TB A\n";
            sql += "WHERE\n";
            sql += "    A.MENTORIA_ID = " + mentoriaItem.Id + "\n";
            return sql; 
        } 

        #endregion 
    
		#region Métodos Específicos do Banco

		private string ObterUltimoItemInseridoSql()
		{
			var sql = this.PrepararSelecaoSql();

			sql += "WHERE \n";

			sql += "    A.MENTORIA_ID = SCOPE_IDENTITY()\n";

			return sql;
		}

		#endregion
	}
}
