using System;
using System.Collections.Generic;

namespace Btp.Hackathon.Core.Persistencia.Mentor 
{ 
    public class MentorItem : _BaseItem, Interface.Mentor.IMentorItem
    { 
        #region Propriedades 

        private string _connectionString { get; set; } 

        #endregion 

        #region Construtores 

        public MentorItem() 
            : this("") 
        { } 

        public MentorItem(string connectionString) 
        { 
            this._connectionString = connectionString; 
        } 

        #endregion 

        #region Métodos Públicos 

        public List<Entidade.Mentor.MentorItem> CarregarLista() 
        { 
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararSelecaoSql(null, null, null); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarLista<Entidade.Mentor.MentorItem>(databaseItem, sql, dicionario); 
        } 

        public List<Entidade.Mentor.MentorItem> CarregarListaPorFuncionarioId(int funcionarioId) 
        { 
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararSelecaoSql(null, funcionarioId, null); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarLista<Entidade.Mentor.MentorItem>(databaseItem, sql, dicionario); 
        } 

        public List<Entidade.Mentor.MentorItem> CarregarListaPorMentorSituacaoId(int mentorSituacaoId) 
        { 
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararSelecaoSql(null, null, mentorSituacaoId); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarLista<Entidade.Mentor.MentorItem>(databaseItem, sql, dicionario); 
        } 

        public Entidade.Mentor.MentorItem CarregarItem(int mentorId)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararSelecaoSql(mentorId, null, null); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            var retorno = base.CarregarItem<Entidade.Mentor.MentorItem>(databaseItem, sql, dicionario); 

            return retorno; 
        }

        public Entidade.Mentor.MentorItem InserirItem(Entidade.Mentor.MentorItem mentorItem)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            var sql = this.PrepararInsercaoSql(mentorItem); 

            sql += this.ObterUltimoItemInseridoSql();

            return base.CarregarItem<Entidade.Mentor.MentorItem>(databaseItem, sql, dicionario); 
        } 

        public Entidade.Mentor.MentorItem AtualizarItem(Entidade.Mentor.MentorItem mentorItem)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararAtualizacaoSql(mentorItem); 

            sql += this.PrepararSelecaoSql(mentorItem.Id, null, null);

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarItem<Entidade.Mentor.MentorItem>(databaseItem, sql, dicionario); 
        } 

        public Entidade.Mentor.MentorItem ExcluirItem(Entidade.Mentor.MentorItem mentorItem)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararExclusaoSql(mentorItem); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarItem<Entidade.Mentor.MentorItem>(databaseItem, sql, dicionario); 
        } 

        #endregion 

        #region Métodos Privados 

        private Dictionary<string, string> ObterDicionarioSelecaoSql()
        { 
            var dicionario = new Dictionary<string, string>(); 

            dicionario.Add("Id", "MENTOR_ID"); 
            dicionario.Add("FuncionarioId", "FUNCIONARIO_ID"); 
            dicionario.Add("MentorSituacaoId", "MENTOR_SITUACAO_ID"); 

            return dicionario; 
        } 

        private string PrepararSelecaoSql()
        { 
            var sql = ""; 

            sql += "SELECT \n";
            sql += "    A.MENTOR_ID,\n";
            sql += "    A.FUNCIONARIO_ID,\n";
            sql += "    A.MENTOR_SITUACAO_ID\n";
            sql += "FROM \n";
            sql += "    MENTOR_TB A\n";

            return sql; 
        } 

        private string PrepararSelecaoSql(int? mentorId, int? funcionarioId, int? mentorSituacaoId)
		{ 
			var sql = ""; 

			if (mentorId.HasValue)
				sql += "A.MENTOR_ID = " + mentorId.Value + "\n";

			if (funcionarioId.HasValue)
				sql += "A.FUNCIONARIO_ID = " + funcionarioId.Value + "\n";

			if (mentorSituacaoId.HasValue)
				sql += "A.MENTOR_SITUACAO_ID = " + mentorSituacaoId.Value + "\n";

            if (!string.IsNullOrEmpty(sql))
            {
                sql = sql.Substring(0, sql.Length - 1);

                sql = sql.Replace("\n", "\nAND "); 

                sql = "WHERE\n\t" + sql; 
            } 

            sql = this.PrepararSelecaoSql() + " " + sql;

            return sql; 
        } 

        private string PrepararInsercaoSql(Entidade.Mentor.MentorItem mentorItem) 
        { 
            var sql = string.Empty; 

            sql += "INSERT INTO MENTOR_TB(\n";
			sql += "    FUNCIONARIO_ID,\n";

			sql += "    MENTOR_SITUACAO_ID,\n";

			sql = sql.Substring(0, sql.Length - 2) + "\n";

			sql += ") VALUES (\n";
			sql += "    " + mentorItem.FuncionarioId.ToString() + ",\n";

			sql += "    " + mentorItem.MentorSituacaoId.ToString() + ",\n";

			sql = sql.Substring(0, sql.Length - 2) + "\n";

            sql += ");\n";

            return sql; 
        } 

        private string PrepararAtualizacaoSql(Entidade.Mentor.MentorItem mentorItem) 
        { 
            var sql = string.Empty; 

            sql += "UPDATE \n";
            sql += "    A\n";
            sql += "SET\n";
			sql += "    A.FUNCIONARIO_ID = " + mentorItem.FuncionarioId.ToString() + ",\n"; 

			sql += "    A.MENTOR_SITUACAO_ID = " + mentorItem.MentorSituacaoId.ToString() + ",\n"; 

			sql = sql.Substring(0, sql.Length - 2) + "\n";

            sql += "FROM\n";
            sql += "    MENTOR_TB A\n";
            sql += "WHERE\n";
            sql += "    A.MENTOR_ID = " + mentorItem.Id + "\n";
            return sql; 
        } 

        private string PrepararExclusaoSql(Entidade.Mentor.MentorItem mentorItem) 
        { 
            var sql = string.Empty; 

            sql += "DELETE \n";
            sql += "    A\n";
            sql += "FROM\n";
            sql += "    MENTOR_TB A\n";
            sql += "WHERE\n";
            sql += "    A.MENTOR_ID = " + mentorItem.Id + "\n";
            return sql; 
        } 

        #endregion 
    
		#region Métodos Específicos do Banco

		private string ObterUltimoItemInseridoSql()
		{
			var sql = this.PrepararSelecaoSql();

			sql += "WHERE \n";

			sql += "    A.MENTOR_ID = SCOPE_IDENTITY()\n";

			return sql;
		}

		#endregion
	}
}
