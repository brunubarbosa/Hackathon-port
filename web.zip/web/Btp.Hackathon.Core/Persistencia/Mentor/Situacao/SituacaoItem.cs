using System;
using System.Collections.Generic;

namespace Btp.Hackathon.Core.Persistencia.Mentor.Situacao 
{ 
    public class SituacaoItem : _BaseItem, Interface.Mentor.Situacao.ISituacaoItem
    { 
        #region Propriedades 

        private string _connectionString { get; set; } 

        #endregion 

        #region Construtores 

        public SituacaoItem() 
            : this("") 
        { } 

        public SituacaoItem(string connectionString) 
        { 
            this._connectionString = connectionString; 
        } 

        #endregion 

        #region Métodos Públicos 

        public List<Entidade.Mentor.Situacao.SituacaoItem> CarregarLista() 
        { 
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararSelecaoSql(null); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarLista<Entidade.Mentor.Situacao.SituacaoItem>(databaseItem, sql, dicionario); 
        } 

        public Entidade.Mentor.Situacao.SituacaoItem CarregarItem(int mentorSituacaoId)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararSelecaoSql(mentorSituacaoId); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            var retorno = base.CarregarItem<Entidade.Mentor.Situacao.SituacaoItem>(databaseItem, sql, dicionario); 

            return retorno; 
        }

        public Entidade.Mentor.Situacao.SituacaoItem InserirItem(Entidade.Mentor.Situacao.SituacaoItem situacaoItem)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            var sql = this.PrepararInsercaoSql(situacaoItem); 

            sql += this.ObterUltimoItemInseridoSql();

            return base.CarregarItem<Entidade.Mentor.Situacao.SituacaoItem>(databaseItem, sql, dicionario); 
        } 

        public Entidade.Mentor.Situacao.SituacaoItem AtualizarItem(Entidade.Mentor.Situacao.SituacaoItem situacaoItem)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararAtualizacaoSql(situacaoItem); 

            sql += this.PrepararSelecaoSql(situacaoItem.Id);

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarItem<Entidade.Mentor.Situacao.SituacaoItem>(databaseItem, sql, dicionario); 
        } 

        public Entidade.Mentor.Situacao.SituacaoItem ExcluirItem(Entidade.Mentor.Situacao.SituacaoItem situacaoItem)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararExclusaoSql(situacaoItem); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarItem<Entidade.Mentor.Situacao.SituacaoItem>(databaseItem, sql, dicionario); 
        } 

        #endregion 

        #region Métodos Privados 

        private Dictionary<string, string> ObterDicionarioSelecaoSql()
        { 
            var dicionario = new Dictionary<string, string>(); 

            dicionario.Add("Id", "MENTOR_SITUACAO_ID"); 
            dicionario.Add("Nome", "NOME"); 

            return dicionario; 
        } 

        private string PrepararSelecaoSql()
        { 
            var sql = ""; 

            sql += "SELECT \n";
            sql += "    A.MENTOR_SITUACAO_ID,\n";
            sql += "    A.NOME\n";
            sql += "FROM \n";
            sql += "    MENTOR_SITUACAO_TB A\n";

            return sql; 
        } 

        private string PrepararSelecaoSql(int? mentorSituacaoId)
		{ 
			var sql = ""; 

			if (mentorSituacaoId.HasValue)
				sql += "A.MENTOR_SITUACAO_ID = " + mentorSituacaoId.Value + "\n";

            if (!string.IsNullOrEmpty(sql))
            {
                sql = sql.Substring(0, sql.Length - 1);

                sql = sql.Replace("\n", "\nAND "); 

                sql = "WHERE\n\t" + sql; 
            } 

            sql = this.PrepararSelecaoSql() + " " + sql;

            return sql; 
        } 

        private string PrepararInsercaoSql(Entidade.Mentor.Situacao.SituacaoItem situacaoItem) 
        { 
            var sql = string.Empty; 

            sql += "INSERT INTO MENTOR_SITUACAO_TB(\n";
			sql += "    NOME,\n";

			sql = sql.Substring(0, sql.Length - 2) + "\n";

			sql += ") VALUES (\n";
			    sql += "    '" + situacaoItem.Nome.Replace("'", "''") + "',\n";

			sql = sql.Substring(0, sql.Length - 2) + "\n";

            sql += ");\n";

            return sql; 
        } 

        private string PrepararAtualizacaoSql(Entidade.Mentor.Situacao.SituacaoItem situacaoItem) 
        { 
            var sql = string.Empty; 

            sql += "UPDATE \n";
            sql += "    A\n";
            sql += "SET\n";
			sql += "    A.NOME = '" + situacaoItem.Nome.Replace("'", "''") + "',\n";

			sql = sql.Substring(0, sql.Length - 2) + "\n";

            sql += "FROM\n";
            sql += "    MENTOR_SITUACAO_TB A\n";
            sql += "WHERE\n";
            sql += "    A.MENTOR_SITUACAO_ID = " + situacaoItem.Id + "\n";
            return sql; 
        } 

        private string PrepararExclusaoSql(Entidade.Mentor.Situacao.SituacaoItem situacaoItem) 
        { 
            var sql = string.Empty; 

            sql += "DELETE \n";
            sql += "    A\n";
            sql += "FROM\n";
            sql += "    MENTOR_SITUACAO_TB A\n";
            sql += "WHERE\n";
            sql += "    A.MENTOR_SITUACAO_ID = " + situacaoItem.Id + "\n";
            return sql; 
        } 

        #endregion 
    
		#region Métodos Específicos do Banco

		private string ObterUltimoItemInseridoSql()
		{
			var sql = this.PrepararSelecaoSql();

			sql += "WHERE \n";

			sql += "    A.MENTOR_SITUACAO_ID = SCOPE_IDENTITY()\n";

			return sql;
		}

		#endregion
	}
}
