using System;
using System.Collections.Generic;

namespace Btp.Hackathon.Core.Persistencia.Mentor.Mentoria.Funcionario 
{ 
    public class FuncionarioItem : _BaseItem, Interface.Mentor.Mentoria.Funcionario.IFuncionarioItem
    { 
        #region Propriedades 

        private string _connectionString { get; set; } 

        #endregion 

        #region Construtores 

        public FuncionarioItem() 
            : this("") 
        { } 

        public FuncionarioItem(string connectionString) 
        { 
            this._connectionString = connectionString; 
        } 

        #endregion 

        #region Métodos Públicos 

        public List<Entidade.Mentor.Mentoria.Funcionario.FuncionarioItem> CarregarLista() 
        { 
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararSelecaoSql(null, null, null); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarLista<Entidade.Mentor.Mentoria.Funcionario.FuncionarioItem>(databaseItem, sql, dicionario); 
        } 

        public List<Entidade.Mentor.Mentoria.Funcionario.FuncionarioItem> CarregarListaPorMentorMentoriaId(int mentorMentoriaId) 
        { 
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararSelecaoSql(null, mentorMentoriaId, null); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarLista<Entidade.Mentor.Mentoria.Funcionario.FuncionarioItem>(databaseItem, sql, dicionario); 
        } 

        public List<Entidade.Mentor.Mentoria.Funcionario.FuncionarioItem> CarregarListaPorFuncionarioId(int funcionarioId) 
        { 
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararSelecaoSql(null, null, funcionarioId); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarLista<Entidade.Mentor.Mentoria.Funcionario.FuncionarioItem>(databaseItem, sql, dicionario); 
        } 

        public Entidade.Mentor.Mentoria.Funcionario.FuncionarioItem CarregarItem(int mentorMentoriaFuncionarioId)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararSelecaoSql(mentorMentoriaFuncionarioId, null, null); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            var retorno = base.CarregarItem<Entidade.Mentor.Mentoria.Funcionario.FuncionarioItem>(databaseItem, sql, dicionario); 

            return retorno; 
        }

        public Entidade.Mentor.Mentoria.Funcionario.FuncionarioItem InserirItem(Entidade.Mentor.Mentoria.Funcionario.FuncionarioItem funcionarioItem)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            var sql = this.PrepararInsercaoSql(funcionarioItem); 

            sql += this.ObterUltimoItemInseridoSql();

            return base.CarregarItem<Entidade.Mentor.Mentoria.Funcionario.FuncionarioItem>(databaseItem, sql, dicionario); 
        } 

        public Entidade.Mentor.Mentoria.Funcionario.FuncionarioItem AtualizarItem(Entidade.Mentor.Mentoria.Funcionario.FuncionarioItem funcionarioItem)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararAtualizacaoSql(funcionarioItem); 

            sql += this.PrepararSelecaoSql(funcionarioItem.Id, null, null);

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarItem<Entidade.Mentor.Mentoria.Funcionario.FuncionarioItem>(databaseItem, sql, dicionario); 
        } 

        public Entidade.Mentor.Mentoria.Funcionario.FuncionarioItem ExcluirItem(Entidade.Mentor.Mentoria.Funcionario.FuncionarioItem funcionarioItem)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararExclusaoSql(funcionarioItem); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarItem<Entidade.Mentor.Mentoria.Funcionario.FuncionarioItem>(databaseItem, sql, dicionario); 
        } 

        #endregion 

        #region Métodos Privados 

        private Dictionary<string, string> ObterDicionarioSelecaoSql()
        { 
            var dicionario = new Dictionary<string, string>(); 

            dicionario.Add("Id", "MENTOR_MENTORIA_FUNCIONARIO_ID"); 
            dicionario.Add("MentorMentoriaId", "MENTOR_MENTORIA_ID"); 
            dicionario.Add("FuncionarioId", "FUNCIONARIO_ID"); 
            dicionario.Add("DataInclusao", "DATA_INCLUSAO"); 

            return dicionario; 
        } 

        private string PrepararSelecaoSql()
        { 
            var sql = ""; 

            sql += "SELECT \n";
            sql += "    A.MENTOR_MENTORIA_FUNCIONARIO_ID,\n";
            sql += "    A.MENTOR_MENTORIA_ID,\n";
            sql += "    A.FUNCIONARIO_ID,\n";
            sql += "    A.DATA_INCLUSAO\n";
            sql += "FROM \n";
            sql += "    MENTOR_MENTORIA_FUNCIONARIO_TB A\n";

            return sql; 
        } 

        private string PrepararSelecaoSql(int? mentorMentoriaFuncionarioId, int? mentorMentoriaId, int? funcionarioId)
		{ 
			var sql = ""; 

			if (mentorMentoriaFuncionarioId.HasValue)
				sql += "A.MENTOR_MENTORIA_FUNCIONARIO_ID = " + mentorMentoriaFuncionarioId.Value + "\n";

			if (mentorMentoriaId.HasValue)
				sql += "A.MENTOR_MENTORIA_ID = " + mentorMentoriaId.Value + "\n";

			if (funcionarioId.HasValue)
				sql += "A.FUNCIONARIO_ID = " + funcionarioId.Value + "\n";

            if (!string.IsNullOrEmpty(sql))
            {
                sql = sql.Substring(0, sql.Length - 1);

                sql = sql.Replace("\n", "\nAND "); 

                sql = "WHERE\n\t" + sql; 
            } 

            sql = this.PrepararSelecaoSql() + " " + sql;

            return sql; 
        } 

        private string PrepararInsercaoSql(Entidade.Mentor.Mentoria.Funcionario.FuncionarioItem funcionarioItem) 
        { 
            var sql = string.Empty; 

            sql += "INSERT INTO MENTOR_MENTORIA_FUNCIONARIO_TB(\n";
			sql += "    MENTOR_MENTORIA_ID,\n";

			sql += "    FUNCIONARIO_ID,\n";

			sql = sql.Substring(0, sql.Length - 2) + "\n";

			sql += ") VALUES (\n";
			sql += "    " + funcionarioItem.MentorMentoriaId.ToString() + ",\n";

			sql += "    " + funcionarioItem.FuncionarioId.ToString() + ",\n";

			sql = sql.Substring(0, sql.Length - 2) + "\n";

            sql += ");\n";

            return sql; 
        } 

        private string PrepararAtualizacaoSql(Entidade.Mentor.Mentoria.Funcionario.FuncionarioItem funcionarioItem) 
        { 
            var sql = string.Empty; 

            sql += "UPDATE \n";
            sql += "    A\n";
            sql += "SET\n";
			sql += "    A.MENTOR_MENTORIA_ID = " + funcionarioItem.MentorMentoriaId.ToString() + ",\n"; 

			sql += "    A.FUNCIONARIO_ID = " + funcionarioItem.FuncionarioId.ToString() + ",\n"; 

			sql = sql.Substring(0, sql.Length - 2) + "\n";

            sql += "FROM\n";
            sql += "    MENTOR_MENTORIA_FUNCIONARIO_TB A\n";
            sql += "WHERE\n";
            sql += "    A.MENTOR_MENTORIA_FUNCIONARIO_ID = " + funcionarioItem.Id + "\n";
            return sql; 
        } 

        private string PrepararExclusaoSql(Entidade.Mentor.Mentoria.Funcionario.FuncionarioItem funcionarioItem) 
        { 
            var sql = string.Empty; 

            sql += "DELETE \n";
            sql += "    A\n";
            sql += "FROM\n";
            sql += "    MENTOR_MENTORIA_FUNCIONARIO_TB A\n";
            sql += "WHERE\n";
            sql += "    A.MENTOR_MENTORIA_FUNCIONARIO_ID = " + funcionarioItem.Id + "\n";
            return sql; 
        } 

        #endregion 
    
		#region Métodos Específicos do Banco

		private string ObterUltimoItemInseridoSql()
		{
			var sql = this.PrepararSelecaoSql();

			sql += "WHERE \n";

			sql += "    A.MENTOR_MENTORIA_FUNCIONARIO_ID = SCOPE_IDENTITY()\n";

			return sql;
		}

		#endregion
	}
}
