using System;
using System.Collections.Generic;

namespace Btp.Hackathon.Core.Persistencia.Mentor.Mentoria 
{ 
    public class MentoriaItem : _BaseItem, Interface.Mentor.Mentoria.IMentoriaItem
    { 
        #region Propriedades 

        private string _connectionString { get; set; } 

        #endregion 

        #region Construtores 

        public MentoriaItem() 
            : this("") 
        { } 

        public MentoriaItem(string connectionString) 
        { 
            this._connectionString = connectionString; 
        } 

        #endregion 

        #region Métodos Públicos 

        public List<Entidade.Mentor.Mentoria.MentoriaItem> CarregarLista() 
        { 
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararSelecaoSql(null, null); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarLista<Entidade.Mentor.Mentoria.MentoriaItem>(databaseItem, sql, dicionario); 
        } 

        public List<Entidade.Mentor.Mentoria.MentoriaItem> CarregarListaPorMentorId(int mentorId) 
        { 
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararSelecaoSql(null, mentorId); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarLista<Entidade.Mentor.Mentoria.MentoriaItem>(databaseItem, sql, dicionario); 
        } 

        public Entidade.Mentor.Mentoria.MentoriaItem CarregarItem(int mentorMentoriaId)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararSelecaoSql(mentorMentoriaId, null); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            var retorno = base.CarregarItem<Entidade.Mentor.Mentoria.MentoriaItem>(databaseItem, sql, dicionario); 

            return retorno; 
        }

        public Entidade.Mentor.Mentoria.MentoriaItem InserirItem(Entidade.Mentor.Mentoria.MentoriaItem mentoriaItem)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            var sql = this.PrepararInsercaoSql(mentoriaItem); 

            sql += this.ObterUltimoItemInseridoSql();

            return base.CarregarItem<Entidade.Mentor.Mentoria.MentoriaItem>(databaseItem, sql, dicionario); 
        } 

        public Entidade.Mentor.Mentoria.MentoriaItem AtualizarItem(Entidade.Mentor.Mentoria.MentoriaItem mentoriaItem)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararAtualizacaoSql(mentoriaItem); 

            sql += this.PrepararSelecaoSql(mentoriaItem.Id, null);

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarItem<Entidade.Mentor.Mentoria.MentoriaItem>(databaseItem, sql, dicionario); 
        } 

        public Entidade.Mentor.Mentoria.MentoriaItem ExcluirItem(Entidade.Mentor.Mentoria.MentoriaItem mentoriaItem)
        {
            var databaseItem = new Btp.Database.DatabaseItem(); 

            var sql = this.PrepararExclusaoSql(mentoriaItem); 

            var dicionario = this.ObterDicionarioSelecaoSql(); 

            return base.CarregarItem<Entidade.Mentor.Mentoria.MentoriaItem>(databaseItem, sql, dicionario); 
        } 

        #endregion 

        #region Métodos Privados 

        private Dictionary<string, string> ObterDicionarioSelecaoSql()
        { 
            var dicionario = new Dictionary<string, string>(); 

            dicionario.Add("Id", "MENTOR_MENTORIA_ID"); 
            dicionario.Add("MentorId", "MENTOR_ID"); 
            dicionario.Add("DataInclusao", "DATA_INCLUSAO"); 

            return dicionario; 
        } 

        private string PrepararSelecaoSql()
        { 
            var sql = ""; 

            sql += "SELECT \n";
            sql += "    A.MENTOR_MENTORIA_ID,\n";
            sql += "    A.MENTOR_ID,\n";
            sql += "    A.DATA_INCLUSAO\n";
            sql += "FROM \n";
            sql += "    MENTOR_MENTORIA_TB A\n";

            return sql; 
        } 

        private string PrepararSelecaoSql(int? mentorMentoriaId, int? mentorId)
		{ 
			var sql = ""; 

			if (mentorMentoriaId.HasValue)
				sql += "A.MENTOR_MENTORIA_ID = " + mentorMentoriaId.Value + "\n";

			if (mentorId.HasValue)
				sql += "A.MENTOR_ID = " + mentorId.Value + "\n";

            if (!string.IsNullOrEmpty(sql))
            {
                sql = sql.Substring(0, sql.Length - 1);

                sql = sql.Replace("\n", "\nAND "); 

                sql = "WHERE\n\t" + sql; 
            } 

            sql = this.PrepararSelecaoSql() + " " + sql;

            return sql; 
        } 

        private string PrepararInsercaoSql(Entidade.Mentor.Mentoria.MentoriaItem mentoriaItem) 
        { 
            var sql = string.Empty; 

            sql += "INSERT INTO MENTOR_MENTORIA_TB(\n";
			sql += "    MENTOR_ID,\n";

			sql = sql.Substring(0, sql.Length - 2) + "\n";

			sql += ") VALUES (\n";
			sql += "    " + mentoriaItem.MentorId.ToString() + ",\n";

			sql = sql.Substring(0, sql.Length - 2) + "\n";

            sql += ");\n";

            return sql; 
        } 

        private string PrepararAtualizacaoSql(Entidade.Mentor.Mentoria.MentoriaItem mentoriaItem) 
        { 
            var sql = string.Empty; 

            sql += "UPDATE \n";
            sql += "    A\n";
            sql += "SET\n";
			sql += "    A.MENTOR_ID = " + mentoriaItem.MentorId.ToString() + ",\n"; 

			sql = sql.Substring(0, sql.Length - 2) + "\n";

            sql += "FROM\n";
            sql += "    MENTOR_MENTORIA_TB A\n";
            sql += "WHERE\n";
            sql += "    A.MENTOR_MENTORIA_ID = " + mentoriaItem.Id + "\n";
            return sql; 
        } 

        private string PrepararExclusaoSql(Entidade.Mentor.Mentoria.MentoriaItem mentoriaItem) 
        { 
            var sql = string.Empty; 

            sql += "DELETE \n";
            sql += "    A\n";
            sql += "FROM\n";
            sql += "    MENTOR_MENTORIA_TB A\n";
            sql += "WHERE\n";
            sql += "    A.MENTOR_MENTORIA_ID = " + mentoriaItem.Id + "\n";
            return sql; 
        } 

        #endregion 
    
		#region Métodos Específicos do Banco

		private string ObterUltimoItemInseridoSql()
		{
			var sql = this.PrepararSelecaoSql();

			sql += "WHERE \n";

			sql += "    A.MENTOR_MENTORIA_ID = SCOPE_IDENTITY()\n";

			return sql;
		}

		#endregion
	}
}
