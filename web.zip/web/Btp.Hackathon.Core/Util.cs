﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Linq;

namespace Btp.Hackathon.Core
{
    public class Util
    {
        public static async Task<string> RequestGetAsync(string url, CookieContainer cookieContainer)
        {
            return await RequestGetAsync(url, cookieContainer, null);
        }

        public static async Task<string> RequestGetAsync(string url, CookieContainer cookieContainer, Dictionary<string, string> headerLista)
        {
            var httpClientHandler = new HttpClientHandler()
            {
                AutomaticDecompression = DecompressionMethods.Deflate | DecompressionMethods.GZip,
                CookieContainer = cookieContainer
            };

            var httpClient = new HttpClient(httpClientHandler)
            {
                Timeout = new TimeSpan(0, 0, 30)
            };

            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;

            var httpRequestMessage = new HttpRequestMessage()
            {
                RequestUri = new Uri(url),
                Method = HttpMethod.Get
            };

            if (headerLista != null && headerLista.Count > 0)
            {
                headerLista
                    .ToList()
                    .ForEach(x => httpRequestMessage.Headers.Add(x.Key, x.Value));
            }

            var httpResponseMessage = httpClient.SendAsync(httpRequestMessage).Result;

            var statusCode = (int)httpResponseMessage.StatusCode;

            if (statusCode >= 300 && statusCode <= 399)
            {
                var redirectUri = httpResponseMessage.Headers.Location;

                if (!redirectUri.IsAbsoluteUri)
                {
                    redirectUri = new Uri(httpRequestMessage.RequestUri.GetLeftPart(UriPartial.Authority) + redirectUri);
                }

                return await RequestGetAsync(redirectUri.ToString(), cookieContainer, headerLista);
            }

            var byteArray = httpResponseMessage.Content.ReadAsByteArrayAsync().Result;

            var responseString = Encoding.UTF8.GetString(byteArray, 0, byteArray.Length);

            return responseString;
        }

        public static async Task<string> RequestPostAsync(string url, Dictionary<string, string> data, CookieContainer cookieContainer, Dictionary<string, string> headerLista)
        {
            var httpClientHandler = new HttpClientHandler
            {
                CookieContainer = cookieContainer
            };

            var httpClient = new HttpClient(httpClientHandler);

            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;

            var httpRequestMessage = new HttpRequestMessage(HttpMethod.Post, url)
            {
                Content = new FormUrlEncodedContent(data)
            };

            if (headerLista != null && headerLista.Count > 0)
            {
                headerLista
                    .ToList()
                    .ForEach(x => httpRequestMessage.Headers.Add(x.Key, x.Value));
            }

            var httpResponseMessage = await httpClient.SendAsync(httpRequestMessage);

            var statusCode = (int)httpResponseMessage.StatusCode;

            if (statusCode >= 300 && statusCode <= 399)
            {
                var redirectUri = httpResponseMessage.Headers.Location;

                if (!redirectUri.IsAbsoluteUri)
                {
                    redirectUri = new Uri(httpRequestMessage.RequestUri.GetLeftPart(UriPartial.Authority) + redirectUri);
                }

                return await RequestGetAsync(redirectUri.ToString(), cookieContainer);
            }

            var html = await httpResponseMessage.Content.ReadAsStringAsync();

            while (html.Contains("\r"))
                html = html.Replace("\r", " ");

            while (html.Contains("\n"))
                html = html.Replace("\n", " ");

            while (html.Contains("\t"))
                html = html.Replace("\t", " ");

            while (html.Contains("  "))
                html = html.Replace("  ", " ");

            while (html.Contains("> <"))
                html = html.Replace("> <", "><");

            while (html.Contains(" >"))
                html = html.Replace(" >", ">");

            while (html.Contains(" <"))
                html = html.Replace(" <", "<");

            return html;
        }

        public static Dictionary<string, string> ObterHtmlElementoLista(string html)
        {
            var parametroLista = new Dictionary<string, string>();

            var tag = "input";

            var attr = "name";

            var regexInput = @"<" + tag + @"[^>]*?" + attr + @"s*=s*[""\']?([^\'"" >]+?)[ \'""][^>]*?>";

            var regexAttr = "(\\S+)=[\"']?((?:.(?![\"']?\\s+(?:\\S+)=|[>\"']))+.)[\"']?";

            var matchLista = Regex.Matches(html, regexInput, RegexOptions.IgnoreCase | RegexOptions.Singleline);

            foreach (Match matchItem in matchLista)
            {
                var attrLista = Regex.Matches(matchItem.Groups[0].Value, regexAttr);

                var attrName = "";

                var attrValue = "";

                foreach (Match attrItem in attrLista)
                {
                    if (attrItem.Groups[1].ToString().Equals("name"))
                        attrName = attrItem.Groups[2].ToString();

                    if (attrItem.Groups[1].ToString().Equals("value"))
                        attrValue = attrItem.Groups[2].ToString();
                }

                parametroLista.Add(attrName, attrValue);
            }

            return parametroLista;
        }
    }
}
