using System;
using System.Collections.Generic;

namespace Btp.Hackathon.Core.Negocio.Curso.Modulo 
{ 
    public class ModuloItem : _BaseItem
    { 
        #region Propriedades 

        private Interface.Curso.Modulo.IModuloItem _persistenciaModuloItem { get; set; } 

        #endregion 

        #region Construtores 

        public ModuloItem() 
            : this(new Persistencia.Curso.Modulo.ModuloItem()) 
        { } 

        public ModuloItem(Interface.Curso.Modulo.IModuloItem persistenciaModuloItem) 
        { 
            this._persistenciaModuloItem = persistenciaModuloItem; 
        } 

        #endregion 

        #region Métodos Públicos 

        public List<Entidade.Curso.Modulo.ModuloItem> CarregarLista() 
        { 
            return _persistenciaModuloItem.CarregarLista(); 
        } 

        public List<Entidade.Curso.Modulo.ModuloItem> CarregarListaPorCursoId(int cursoId) 
        { 
            return _persistenciaModuloItem.CarregarListaPorCursoId(cursoId); 
        } 

        public Entidade.Curso.Modulo.ModuloItem CarregarItem(int cursoModuloId)
        {
            return _persistenciaModuloItem.CarregarItem(cursoModuloId);
        }

        public Entidade.Curso.Modulo.ModuloItem InserirItem(Entidade.Curso.Modulo.ModuloItem moduloItem)
        {
            return _persistenciaModuloItem.InserirItem(moduloItem); 
        } 

        public Entidade.Curso.Modulo.ModuloItem AtualizarItem(Entidade.Curso.Modulo.ModuloItem moduloItem)
        {
            return _persistenciaModuloItem.AtualizarItem(moduloItem); 
        } 

        public Entidade.Curso.Modulo.ModuloItem ExcluirItem(Entidade.Curso.Modulo.ModuloItem moduloItem)
        {
            return _persistenciaModuloItem.ExcluirItem(moduloItem); 
        } 

        public Entidade.Curso.Modulo.ModuloItem SalvarItem(Entidade.Curso.Modulo.ModuloItem moduloItem)
        {
            if (moduloItem.Id.Equals(0))
                moduloItem = this.InserirItem(moduloItem);
            else
                moduloItem = this.AtualizarItem(moduloItem);

            return moduloItem;
        }

        #endregion 
    } 
} 
