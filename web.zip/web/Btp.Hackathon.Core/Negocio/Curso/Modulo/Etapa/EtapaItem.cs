using System;
using System.Collections.Generic;

namespace Btp.Hackathon.Core.Negocio.Curso.Modulo.Etapa 
{ 
    public class EtapaItem : _BaseItem
    { 
        #region Propriedades 

        private Interface.Curso.Modulo.Etapa.IEtapaItem _persistenciaEtapaItem { get; set; } 

        #endregion 

        #region Construtores 

        public EtapaItem() 
            : this(new Persistencia.Curso.Modulo.Etapa.EtapaItem()) 
        { } 

        public EtapaItem(Interface.Curso.Modulo.Etapa.IEtapaItem persistenciaEtapaItem) 
        { 
            this._persistenciaEtapaItem = persistenciaEtapaItem; 
        } 

        #endregion 

        #region Métodos Públicos 

        public List<Entidade.Curso.Modulo.Etapa.EtapaItem> CarregarLista() 
        { 
            return _persistenciaEtapaItem.CarregarLista(); 
        } 

        public Entidade.Curso.Modulo.Etapa.EtapaItem CarregarItem(int cursoModuloEtapaId)
        {
            return _persistenciaEtapaItem.CarregarItem(cursoModuloEtapaId);
        }

        public Entidade.Curso.Modulo.Etapa.EtapaItem InserirItem(Entidade.Curso.Modulo.Etapa.EtapaItem etapaItem)
        {
            return _persistenciaEtapaItem.InserirItem(etapaItem); 
        } 

        public Entidade.Curso.Modulo.Etapa.EtapaItem AtualizarItem(Entidade.Curso.Modulo.Etapa.EtapaItem etapaItem)
        {
            return _persistenciaEtapaItem.AtualizarItem(etapaItem); 
        } 

        public Entidade.Curso.Modulo.Etapa.EtapaItem ExcluirItem(Entidade.Curso.Modulo.Etapa.EtapaItem etapaItem)
        {
            return _persistenciaEtapaItem.ExcluirItem(etapaItem); 
        } 

        public Entidade.Curso.Modulo.Etapa.EtapaItem SalvarItem(Entidade.Curso.Modulo.Etapa.EtapaItem etapaItem)
        {
            if (etapaItem.Id.Equals(0))
                etapaItem = this.InserirItem(etapaItem);
            else
                etapaItem = this.AtualizarItem(etapaItem);

            return etapaItem;
        }

        #endregion 
    } 
} 
