using System;
using System.Collections.Generic;

namespace Btp.Hackathon.Core.Negocio.Curso.Modulo.Acesso 
{ 
    public class AcessoItem : _BaseItem
    { 
        #region Propriedades 

        private Interface.Curso.Modulo.Acesso.IAcessoItem _persistenciaAcessoItem { get; set; } 

        #endregion 

        #region Construtores 

        public AcessoItem() 
            : this(new Persistencia.Curso.Modulo.Acesso.AcessoItem()) 
        { } 

        public AcessoItem(Interface.Curso.Modulo.Acesso.IAcessoItem persistenciaAcessoItem) 
        { 
            this._persistenciaAcessoItem = persistenciaAcessoItem; 
        } 

        #endregion 

        #region Métodos Públicos 

        public List<Entidade.Curso.Modulo.Acesso.AcessoItem> CarregarLista() 
        { 
            return _persistenciaAcessoItem.CarregarLista(); 
        } 
        
        public List<Entidade.Curso.Modulo.Acesso.AcessoItem> CarregarListaPorFuncionarioId(int funcionarioId) 
        { 
            return _persistenciaAcessoItem.CarregarListaPorFuncionarioId(funcionarioId); 
        } 

        public Entidade.Curso.Modulo.Acesso.AcessoItem CarregarItem(int cursoModuloAcessoId)
        {
            return _persistenciaAcessoItem.CarregarItem(cursoModuloAcessoId);
        }

        public Entidade.Curso.Modulo.Acesso.AcessoItem InserirItem(Entidade.Curso.Modulo.Acesso.AcessoItem acessoItem)
        {
            return _persistenciaAcessoItem.InserirItem(acessoItem); 
        } 

        public Entidade.Curso.Modulo.Acesso.AcessoItem AtualizarItem(Entidade.Curso.Modulo.Acesso.AcessoItem acessoItem)
        {
            return _persistenciaAcessoItem.AtualizarItem(acessoItem); 
        } 

        public Entidade.Curso.Modulo.Acesso.AcessoItem ExcluirItem(Entidade.Curso.Modulo.Acesso.AcessoItem acessoItem)
        {
            return _persistenciaAcessoItem.ExcluirItem(acessoItem); 
        } 

        public Entidade.Curso.Modulo.Acesso.AcessoItem SalvarItem(Entidade.Curso.Modulo.Acesso.AcessoItem acessoItem)
        {
            if (acessoItem.Id.Equals(0))
                acessoItem = this.InserirItem(acessoItem);
            else
                acessoItem = this.AtualizarItem(acessoItem);

            return acessoItem;
        }
        
        #endregion 
    } 
} 
