using System;
using System.Collections.Generic;

namespace Btp.Hackathon.Core.Negocio.Curso.Prioridade 
{ 
    public class PrioridadeItem : _BaseItem
    { 
        #region Propriedades 

        private Interface.Curso.Prioridade.IPrioridadeItem _persistenciaPrioridadeItem { get; set; } 

        #endregion 

        #region Construtores 

        public PrioridadeItem() 
            : this(new Persistencia.Curso.Prioridade.PrioridadeItem()) 
        { } 

        public PrioridadeItem(Interface.Curso.Prioridade.IPrioridadeItem persistenciaPrioridadeItem) 
        { 
            this._persistenciaPrioridadeItem = persistenciaPrioridadeItem; 
        } 

        #endregion 

        #region Métodos Públicos 

        public List<Entidade.Curso.Prioridade.PrioridadeItem> CarregarLista() 
        { 
            return _persistenciaPrioridadeItem.CarregarLista(); 
        } 

        public Entidade.Curso.Prioridade.PrioridadeItem CarregarItem(int cursoPrioridadeId)
        {
            return _persistenciaPrioridadeItem.CarregarItem(cursoPrioridadeId);
        }

        public Entidade.Curso.Prioridade.PrioridadeItem InserirItem(Entidade.Curso.Prioridade.PrioridadeItem prioridadeItem)
        {
            return _persistenciaPrioridadeItem.InserirItem(prioridadeItem); 
        } 

        public Entidade.Curso.Prioridade.PrioridadeItem AtualizarItem(Entidade.Curso.Prioridade.PrioridadeItem prioridadeItem)
        {
            return _persistenciaPrioridadeItem.AtualizarItem(prioridadeItem); 
        } 

        public Entidade.Curso.Prioridade.PrioridadeItem ExcluirItem(Entidade.Curso.Prioridade.PrioridadeItem prioridadeItem)
        {
            return _persistenciaPrioridadeItem.ExcluirItem(prioridadeItem); 
        } 

        public Entidade.Curso.Prioridade.PrioridadeItem SalvarItem(Entidade.Curso.Prioridade.PrioridadeItem prioridadeItem)
        {
            if (prioridadeItem.Id.Equals(0))
                prioridadeItem = this.InserirItem(prioridadeItem);
            else
                prioridadeItem = this.AtualizarItem(prioridadeItem);

            return prioridadeItem;
        }

        #endregion 
    } 
} 
