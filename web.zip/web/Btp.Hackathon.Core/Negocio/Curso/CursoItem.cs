using System;
using System.Collections.Generic;

namespace Btp.Hackathon.Core.Negocio.Curso 
{ 
    public class CursoItem : _BaseItem
    { 
        #region Propriedades 

        private Interface.Curso.ICursoItem _persistenciaCursoItem { get; set; } 

        #endregion 

        #region Construtores 

        public CursoItem() 
            : this(new Persistencia.Curso.CursoItem()) 
        { } 

        public CursoItem(Interface.Curso.ICursoItem persistenciaCursoItem) 
        { 
            this._persistenciaCursoItem = persistenciaCursoItem; 
        } 

        #endregion 

        #region Métodos Públicos 

        public List<Entidade.Curso.CursoItem> CarregarLista() 
        { 
            return _persistenciaCursoItem.CarregarLista(); 
        }

        public List<Entidade.Curso.CursoItem> CarregarListaPorFuncionarioId(int funcionarioId)
        {
            return _persistenciaCursoItem.CarregarListaPorFuncionarioId(funcionarioId);
        }

        public List<Entidade.Curso.CursoItem> CarregarListaPorDepartamentoId(int departamentoId) 
        { 
            return _persistenciaCursoItem.CarregarListaPorDepartamentoId(departamentoId); 
        } 

        public Entidade.Curso.CursoItem CarregarItem(int cursoId)
        {
            return _persistenciaCursoItem.CarregarItem(cursoId);
        }

        public Entidade.Curso.CursoItem InserirItem(Entidade.Curso.CursoItem cursoItem)
        {
            return _persistenciaCursoItem.InserirItem(cursoItem); 
        } 

        public Entidade.Curso.CursoItem AtualizarItem(Entidade.Curso.CursoItem cursoItem)
        {
            return _persistenciaCursoItem.AtualizarItem(cursoItem); 
        } 

        public Entidade.Curso.CursoItem ExcluirItem(Entidade.Curso.CursoItem cursoItem)
        {
            return _persistenciaCursoItem.ExcluirItem(cursoItem); 
        } 

        public Entidade.Curso.CursoItem SalvarItem(Entidade.Curso.CursoItem cursoItem)
        {
            if (cursoItem.Id.Equals(0))
                cursoItem = this.InserirItem(cursoItem);
            else
                cursoItem = this.AtualizarItem(cursoItem);

            return cursoItem;
        }
        
        #endregion 
    } 
} 
