using System;
using System.Collections.Generic;

namespace Btp.Hackathon.Core.Negocio.Cargo 
{ 
    public class CargoItem : _BaseItem
    { 
        #region Propriedades 

        private Interface.Cargo.ICargoItem _persistenciaCargoItem { get; set; } 

        #endregion 

        #region Construtores 

        public CargoItem() 
            : this(new Persistencia.Cargo.CargoItem()) 
        { } 

        public CargoItem(Interface.Cargo.ICargoItem persistenciaCargoItem) 
        { 
            this._persistenciaCargoItem = persistenciaCargoItem; 
        } 

        #endregion 

        #region Métodos Públicos 

        public List<Entidade.Cargo.CargoItem> CarregarLista() 
        { 
            return _persistenciaCargoItem.CarregarLista(); 
        } 

        public Entidade.Cargo.CargoItem CarregarItem(int cargoId)
        {
            return _persistenciaCargoItem.CarregarItem(cargoId);
        }

        public Entidade.Cargo.CargoItem InserirItem(Entidade.Cargo.CargoItem cargoItem)
        {
            return _persistenciaCargoItem.InserirItem(cargoItem); 
        } 

        public Entidade.Cargo.CargoItem AtualizarItem(Entidade.Cargo.CargoItem cargoItem)
        {
            return _persistenciaCargoItem.AtualizarItem(cargoItem); 
        } 

        public Entidade.Cargo.CargoItem ExcluirItem(Entidade.Cargo.CargoItem cargoItem)
        {
            return _persistenciaCargoItem.ExcluirItem(cargoItem); 
        } 

        public Entidade.Cargo.CargoItem SalvarItem(Entidade.Cargo.CargoItem cargoItem)
        {
            if (cargoItem.Id.Equals(0))
                cargoItem = this.InserirItem(cargoItem);
            else
                cargoItem = this.AtualizarItem(cargoItem);

            return cargoItem;
        }
        
        #endregion 
    } 
} 
