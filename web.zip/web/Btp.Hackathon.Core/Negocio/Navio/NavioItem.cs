using System;
using System.Collections.Generic;

namespace Btp.Hackathon.Core.Negocio.Navio 
{ 
    public class NavioItem : _BaseItem
    { 
        #region Propriedades 

        private Interface.Navio.INavioItem _persistenciaNavioItem { get; set; } 

        #endregion 

        #region Construtores 

        public NavioItem() 
            : this(new Persistencia.Navio.NavioItem()) 
        { } 

        public NavioItem(Interface.Navio.INavioItem persistenciaNavioItem) 
        { 
            this._persistenciaNavioItem = persistenciaNavioItem; 
        } 

        #endregion 

        #region Métodos Públicos 

        public List<Entidade.Navio.NavioItem> CarregarLista() 
        { 
            return _persistenciaNavioItem.CarregarLista(); 
        } 

        public List<Entidade.Navio.NavioItem> CarregarListaPorNavioSituacaoId(int navioSituacaoId) 
        { 
            return _persistenciaNavioItem.CarregarListaPorNavioSituacaoId(navioSituacaoId); 
        } 

        public Entidade.Navio.NavioItem CarregarItem(int navioId)
        {
            return _persistenciaNavioItem.CarregarItem(navioId);
        }

        public Entidade.Navio.NavioItem InserirItem(Entidade.Navio.NavioItem navioItem)
        {
            return _persistenciaNavioItem.InserirItem(navioItem); 
        } 

        public Entidade.Navio.NavioItem AtualizarItem(Entidade.Navio.NavioItem navioItem)
        {
            return _persistenciaNavioItem.AtualizarItem(navioItem); 
        } 

        public Entidade.Navio.NavioItem ExcluirItem(Entidade.Navio.NavioItem navioItem)
        {
            return _persistenciaNavioItem.ExcluirItem(navioItem); 
        } 

        public Entidade.Navio.NavioItem SalvarItem(Entidade.Navio.NavioItem navioItem)
        {
            if (navioItem.Id.Equals(0))
                navioItem = this.InserirItem(navioItem);
            else
                navioItem = this.AtualizarItem(navioItem);

            return navioItem;
        }
        
        #endregion 
    } 
} 
