using System;
using System.Collections.Generic;

namespace Btp.Hackathon.Core.Negocio.Mentor.Situacao 
{ 
    public class SituacaoItem : _BaseItem
    { 
        #region Propriedades 

        private Interface.Mentor.Situacao.ISituacaoItem _persistenciaSituacaoItem { get; set; } 

        #endregion 

        #region Construtores 

        public SituacaoItem() 
            : this(new Persistencia.Mentor.Situacao.SituacaoItem()) 
        { } 

        public SituacaoItem(Interface.Mentor.Situacao.ISituacaoItem persistenciaSituacaoItem) 
        { 
            this._persistenciaSituacaoItem = persistenciaSituacaoItem; 
        } 

        #endregion 

        #region Métodos Públicos 

        public List<Entidade.Mentor.Situacao.SituacaoItem> CarregarLista() 
        { 
            return _persistenciaSituacaoItem.CarregarLista(); 
        } 

        public Entidade.Mentor.Situacao.SituacaoItem CarregarItem(int mentorSituacaoId)
        {
            return _persistenciaSituacaoItem.CarregarItem(mentorSituacaoId);
        }

        public Entidade.Mentor.Situacao.SituacaoItem InserirItem(Entidade.Mentor.Situacao.SituacaoItem situacaoItem)
        {
            return _persistenciaSituacaoItem.InserirItem(situacaoItem); 
        } 

        public Entidade.Mentor.Situacao.SituacaoItem AtualizarItem(Entidade.Mentor.Situacao.SituacaoItem situacaoItem)
        {
            return _persistenciaSituacaoItem.AtualizarItem(situacaoItem); 
        } 

        public Entidade.Mentor.Situacao.SituacaoItem ExcluirItem(Entidade.Mentor.Situacao.SituacaoItem situacaoItem)
        {
            return _persistenciaSituacaoItem.ExcluirItem(situacaoItem); 
        } 

        public Entidade.Mentor.Situacao.SituacaoItem SalvarItem(Entidade.Mentor.Situacao.SituacaoItem situacaoItem)
        {
            if (situacaoItem.Id.Equals(0))
                situacaoItem = this.InserirItem(situacaoItem);
            else
                situacaoItem = this.AtualizarItem(situacaoItem);

            return situacaoItem;
        }
        
        #endregion 
    } 
} 
