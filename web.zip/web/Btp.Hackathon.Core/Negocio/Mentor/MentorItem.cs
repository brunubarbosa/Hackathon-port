using System;
using System.Collections.Generic;

namespace Btp.Hackathon.Core.Negocio.Mentor 
{ 
    public class MentorItem : _BaseItem
    { 
        #region Propriedades 

        private Interface.Mentor.IMentorItem _persistenciaMentorItem { get; set; } 

        #endregion 

        #region Construtores 

        public MentorItem() 
            : this(new Persistencia.Mentor.MentorItem()) 
        { } 

        public MentorItem(Interface.Mentor.IMentorItem persistenciaMentorItem) 
        { 
            this._persistenciaMentorItem = persistenciaMentorItem; 
        } 

        #endregion 

        #region Métodos Públicos 

        public List<Entidade.Mentor.MentorItem> CarregarLista() 
        { 
            return _persistenciaMentorItem.CarregarLista(); 
        } 

        public List<Entidade.Mentor.MentorItem> CarregarListaPorFuncionarioId(int funcionarioId) 
        { 
            return _persistenciaMentorItem.CarregarListaPorFuncionarioId(funcionarioId); 
        } 

        public List<Entidade.Mentor.MentorItem> CarregarListaPorMentorSituacaoId(int mentorSituacaoId) 
        { 
            return _persistenciaMentorItem.CarregarListaPorMentorSituacaoId(mentorSituacaoId); 
        } 

        public Entidade.Mentor.MentorItem CarregarItem(int mentorId)
        {
            return _persistenciaMentorItem.CarregarItem(mentorId);
        }

        public Entidade.Mentor.MentorItem InserirItem(Entidade.Mentor.MentorItem mentorItem)
        {
            return _persistenciaMentorItem.InserirItem(mentorItem); 
        } 

        public Entidade.Mentor.MentorItem AtualizarItem(Entidade.Mentor.MentorItem mentorItem)
        {
            return _persistenciaMentorItem.AtualizarItem(mentorItem); 
        } 

        public Entidade.Mentor.MentorItem ExcluirItem(Entidade.Mentor.MentorItem mentorItem)
        {
            return _persistenciaMentorItem.ExcluirItem(mentorItem); 
        } 

        public Entidade.Mentor.MentorItem SalvarItem(Entidade.Mentor.MentorItem mentorItem)
        {
            if (mentorItem.Id.Equals(0))
                mentorItem = this.InserirItem(mentorItem);
            else
                mentorItem = this.AtualizarItem(mentorItem);

            return mentorItem;
        }

        #endregion 
    } 
} 
