using System;
using System.Collections.Generic;

namespace Btp.Hackathon.Core.Negocio.Mentor.Mentoria.Funcionario 
{ 
    public class FuncionarioItem : _BaseItem
    { 
        #region Propriedades 

        private Interface.Mentor.Mentoria.Funcionario.IFuncionarioItem _persistenciaFuncionarioItem { get; set; } 

        #endregion 

        #region Construtores 

        public FuncionarioItem() 
            : this(new Persistencia.Mentor.Mentoria.Funcionario.FuncionarioItem()) 
        { } 

        public FuncionarioItem(Interface.Mentor.Mentoria.Funcionario.IFuncionarioItem persistenciaFuncionarioItem) 
        { 
            this._persistenciaFuncionarioItem = persistenciaFuncionarioItem; 
        } 

        #endregion 

        #region Métodos Públicos 

        public List<Entidade.Mentor.Mentoria.Funcionario.FuncionarioItem> CarregarLista() 
        { 
            return _persistenciaFuncionarioItem.CarregarLista(); 
        } 

        public List<Entidade.Mentor.Mentoria.Funcionario.FuncionarioItem> CarregarListaPorMentorMentoriaId(int mentorMentoriaId) 
        { 
            return _persistenciaFuncionarioItem.CarregarListaPorMentorMentoriaId(mentorMentoriaId); 
        } 

        public List<Entidade.Mentor.Mentoria.Funcionario.FuncionarioItem> CarregarListaPorFuncionarioId(int funcionarioId) 
        { 
            return _persistenciaFuncionarioItem.CarregarListaPorFuncionarioId(funcionarioId); 
        } 

        public Entidade.Mentor.Mentoria.Funcionario.FuncionarioItem CarregarItem(int mentorMentoriaFuncionarioId)
        {
            return _persistenciaFuncionarioItem.CarregarItem(mentorMentoriaFuncionarioId);
        }

        public Entidade.Mentor.Mentoria.Funcionario.FuncionarioItem InserirItem(Entidade.Mentor.Mentoria.Funcionario.FuncionarioItem funcionarioItem)
        {
            return _persistenciaFuncionarioItem.InserirItem(funcionarioItem); 
        } 

        public Entidade.Mentor.Mentoria.Funcionario.FuncionarioItem AtualizarItem(Entidade.Mentor.Mentoria.Funcionario.FuncionarioItem funcionarioItem)
        {
            return _persistenciaFuncionarioItem.AtualizarItem(funcionarioItem); 
        } 

        public Entidade.Mentor.Mentoria.Funcionario.FuncionarioItem ExcluirItem(Entidade.Mentor.Mentoria.Funcionario.FuncionarioItem funcionarioItem)
        {
            return _persistenciaFuncionarioItem.ExcluirItem(funcionarioItem); 
        } 

        public Entidade.Mentor.Mentoria.Funcionario.FuncionarioItem SalvarItem(Entidade.Mentor.Mentoria.Funcionario.FuncionarioItem funcionarioItem)
        {
            if (funcionarioItem.Id.Equals(0))
                funcionarioItem = this.InserirItem(funcionarioItem);
            else
                funcionarioItem = this.AtualizarItem(funcionarioItem);

            return funcionarioItem;
        }

        #endregion 
    } 
} 
