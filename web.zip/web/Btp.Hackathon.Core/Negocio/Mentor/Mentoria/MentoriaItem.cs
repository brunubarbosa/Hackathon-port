using System;
using System.Collections.Generic;

namespace Btp.Hackathon.Core.Negocio.Mentor.Mentoria 
{ 
    public class MentoriaItem : _BaseItem
    { 
        #region Propriedades 

        private Interface.Mentor.Mentoria.IMentoriaItem _persistenciaMentoriaItem { get; set; } 

        #endregion 

        #region Construtores 

        public MentoriaItem() 
            : this(new Persistencia.Mentor.Mentoria.MentoriaItem()) 
        { } 

        public MentoriaItem(Interface.Mentor.Mentoria.IMentoriaItem persistenciaMentoriaItem) 
        { 
            this._persistenciaMentoriaItem = persistenciaMentoriaItem; 
        } 

        #endregion 

        #region Métodos Públicos 

        public List<Entidade.Mentor.Mentoria.MentoriaItem> CarregarLista() 
        { 
            return _persistenciaMentoriaItem.CarregarLista(); 
        } 

        public List<Entidade.Mentor.Mentoria.MentoriaItem> CarregarListaPorMentorId(int mentorId) 
        { 
            return _persistenciaMentoriaItem.CarregarListaPorMentorId(mentorId); 
        } 

        public Entidade.Mentor.Mentoria.MentoriaItem CarregarItem(int mentorMentoriaId)
        {
            return _persistenciaMentoriaItem.CarregarItem(mentorMentoriaId);
        }

        public Entidade.Mentor.Mentoria.MentoriaItem InserirItem(Entidade.Mentor.Mentoria.MentoriaItem mentoriaItem)
        {
            return _persistenciaMentoriaItem.InserirItem(mentoriaItem); 
        } 

        public Entidade.Mentor.Mentoria.MentoriaItem AtualizarItem(Entidade.Mentor.Mentoria.MentoriaItem mentoriaItem)
        {
            return _persistenciaMentoriaItem.AtualizarItem(mentoriaItem); 
        } 

        public Entidade.Mentor.Mentoria.MentoriaItem ExcluirItem(Entidade.Mentor.Mentoria.MentoriaItem mentoriaItem)
        {
            return _persistenciaMentoriaItem.ExcluirItem(mentoriaItem); 
        } 

        public Entidade.Mentor.Mentoria.MentoriaItem SalvarItem(Entidade.Mentor.Mentoria.MentoriaItem mentoriaItem)
        {
            if (mentoriaItem.Id.Equals(0))
                mentoriaItem = this.InserirItem(mentoriaItem);
            else
                mentoriaItem = this.AtualizarItem(mentoriaItem);

            return mentoriaItem;
        }
        
        #endregion 
    } 
} 
