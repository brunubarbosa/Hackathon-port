using System;
using System.Collections.Generic;

namespace Btp.Hackathon.Core.Negocio.Departamento 
{ 
    public class DepartamentoItem : _BaseItem
    { 
        #region Propriedades 

        private Interface.Departamento.IDepartamentoItem _persistenciaDepartamentoItem { get; set; } 

        #endregion 

        #region Construtores 

        public DepartamentoItem() 
            : this(new Persistencia.Departamento.DepartamentoItem()) 
        { } 

        public DepartamentoItem(Interface.Departamento.IDepartamentoItem persistenciaDepartamentoItem) 
        { 
            this._persistenciaDepartamentoItem = persistenciaDepartamentoItem; 
        } 

        #endregion 

        #region Métodos Públicos 

        public List<Entidade.Departamento.DepartamentoItem> CarregarLista() 
        { 
            return _persistenciaDepartamentoItem.CarregarLista(); 
        } 

        public Entidade.Departamento.DepartamentoItem CarregarItem(int departamentoId)
        {
            return _persistenciaDepartamentoItem.CarregarItem(departamentoId);
        }

        public Entidade.Departamento.DepartamentoItem InserirItem(Entidade.Departamento.DepartamentoItem departamentoItem)
        {
            return _persistenciaDepartamentoItem.InserirItem(departamentoItem); 
        } 

        public Entidade.Departamento.DepartamentoItem AtualizarItem(Entidade.Departamento.DepartamentoItem departamentoItem)
        {
            return _persistenciaDepartamentoItem.AtualizarItem(departamentoItem); 
        } 

        public Entidade.Departamento.DepartamentoItem ExcluirItem(Entidade.Departamento.DepartamentoItem departamentoItem)
        {
            return _persistenciaDepartamentoItem.ExcluirItem(departamentoItem); 
        } 

        public Entidade.Departamento.DepartamentoItem SalvarItem(Entidade.Departamento.DepartamentoItem departamentoItem)
        {
            if (departamentoItem.Id.Equals(0))
                departamentoItem = this.InserirItem(departamentoItem);
            else
                departamentoItem = this.AtualizarItem(departamentoItem);

            return departamentoItem;
        }

        #endregion 
    } 
} 
