using System;
using System.Collections.Generic;

namespace Btp.Hackathon.Core.Negocio.Funcionario 
{ 
    public class FuncionarioItem : _BaseItem
    { 
        #region Propriedades 

        private Interface.Funcionario.IFuncionarioItem _persistenciaFuncionarioItem { get; set; } 

        #endregion 

        #region Construtores 

        public FuncionarioItem() 
            : this(new Persistencia.Funcionario.FuncionarioItem()) 
        { } 

        public FuncionarioItem(Interface.Funcionario.IFuncionarioItem persistenciaFuncionarioItem) 
        { 
            this._persistenciaFuncionarioItem = persistenciaFuncionarioItem; 
        } 

        #endregion 

        #region Métodos Públicos 

        public List<Entidade.Funcionario.FuncionarioItem> CarregarLista() 
        { 
            return _persistenciaFuncionarioItem.CarregarLista(); 
        } 

        public List<Entidade.Funcionario.FuncionarioItem> CarregarListaPorDepartamentoId(int departamentoId) 
        { 
            return _persistenciaFuncionarioItem.CarregarListaPorDepartamentoId(departamentoId); 
        } 

        public List<Entidade.Funcionario.FuncionarioItem> CarregarListaPorCargoId(int cargoId) 
        { 
            return _persistenciaFuncionarioItem.CarregarListaPorCargoId(cargoId); 
        }

        public List<Entidade.Funcionario.FuncionarioItem> CarregarListaPorNavioId(int navioId)
        {
            return _persistenciaFuncionarioItem.CarregarListaPorNavioId(navioId);
        }

        public Entidade.Funcionario.FuncionarioItem CarregarItem(int funcionarioId)
        {
            return _persistenciaFuncionarioItem.CarregarItem(funcionarioId);
        }

        public Entidade.Funcionario.FuncionarioItem InserirItem(Entidade.Funcionario.FuncionarioItem funcionarioItem)
        {
            return _persistenciaFuncionarioItem.InserirItem(funcionarioItem); 
        } 

        public Entidade.Funcionario.FuncionarioItem AtualizarItem(Entidade.Funcionario.FuncionarioItem funcionarioItem)
        {
            return _persistenciaFuncionarioItem.AtualizarItem(funcionarioItem); 
        } 

        public Entidade.Funcionario.FuncionarioItem ExcluirItem(Entidade.Funcionario.FuncionarioItem funcionarioItem)
        {
            return _persistenciaFuncionarioItem.ExcluirItem(funcionarioItem); 
        } 

        public Entidade.Funcionario.FuncionarioItem SalvarItem(Entidade.Funcionario.FuncionarioItem funcionarioItem)
        {
            if (funcionarioItem.Id.Equals(0))
                funcionarioItem = this.InserirItem(funcionarioItem);
            else
                funcionarioItem = this.AtualizarItem(funcionarioItem);

            return funcionarioItem;
        }
        
        #endregion 
    } 
} 
