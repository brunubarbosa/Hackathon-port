using System;
using System.Collections.Generic;

namespace Btp.Hackathon.Core.Negocio.Mentoria 
{ 
    public class MentoriaItem : _BaseItem
    { 
        #region Propriedades 

        private Interface.Mentoria.IMentoriaItem _persistenciaMentoriaItem { get; set; } 

        #endregion 

        #region Construtores 

        public MentoriaItem() 
            : this(new Persistencia.Mentoria.MentoriaItem()) 
        { } 

        public MentoriaItem(Interface.Mentoria.IMentoriaItem persistenciaMentoriaItem) 
        { 
            this._persistenciaMentoriaItem = persistenciaMentoriaItem; 
        } 

        #endregion 

        #region Métodos Públicos 

        public List<Entidade.Mentoria.MentoriaItem> CarregarLista() 
        { 
            return _persistenciaMentoriaItem.CarregarLista(); 
        } 

        public List<Entidade.Mentoria.MentoriaItem> CarregarListaPorDepartamentoId(int departamentoId) 
        { 
            return _persistenciaMentoriaItem.CarregarListaPorDepartamentoId(departamentoId); 
        } 

        public List<Entidade.Mentoria.MentoriaItem> CarregarListaPorFuncionarioId(int funcionarioId) 
        { 
            return _persistenciaMentoriaItem.CarregarListaPorFuncionarioId(funcionarioId); 
        } 

        public Entidade.Mentoria.MentoriaItem CarregarItem(int mentoriaId)
        {
            return _persistenciaMentoriaItem.CarregarItem(mentoriaId);
        }

        public Entidade.Mentoria.MentoriaItem InserirItem(Entidade.Mentoria.MentoriaItem mentoriaItem)
        {
            return _persistenciaMentoriaItem.InserirItem(mentoriaItem); 
        } 

        public Entidade.Mentoria.MentoriaItem AtualizarItem(Entidade.Mentoria.MentoriaItem mentoriaItem)
        {
            return _persistenciaMentoriaItem.AtualizarItem(mentoriaItem); 
        } 

        public Entidade.Mentoria.MentoriaItem ExcluirItem(Entidade.Mentoria.MentoriaItem mentoriaItem)
        {
            return _persistenciaMentoriaItem.ExcluirItem(mentoriaItem); 
        } 

        public Entidade.Mentoria.MentoriaItem SalvarItem(Entidade.Mentoria.MentoriaItem mentoriaItem)
        {
            if (mentoriaItem.Id.Equals(0))
                mentoriaItem = this.InserirItem(mentoriaItem);
            else
                mentoriaItem = this.AtualizarItem(mentoriaItem);

            return mentoriaItem;
        }
        
        #endregion 
    } 
} 
