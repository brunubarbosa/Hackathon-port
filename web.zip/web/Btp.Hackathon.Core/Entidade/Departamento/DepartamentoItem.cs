using System;

namespace Btp.Hackathon.Core.Entidade.Departamento 
{ 
    public class DepartamentoItem : _BaseItem 
    { 
        public string Nome { get; set; } 
    } 
} 
