using System;

namespace Btp.Hackathon.Core.Entidade.Mentor.Mentoria.Funcionario 
{ 
    public class FuncionarioItem : _BaseItem 
    { 
        public int MentorMentoriaId { get; set; } 

        public int FuncionarioId { get; set; } 

        public DateTime DataInclusao { get; set; } 
    } 
} 
