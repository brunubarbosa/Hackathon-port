using System;

namespace Btp.Hackathon.Core.Entidade.Mentor.Mentoria 
{ 
    public class MentoriaItem : _BaseItem 
    { 
        public int MentorId { get; set; } 

        public DateTime DataInclusao { get; set; } 
    } 
} 
