using System;

namespace Btp.Hackathon.Core.Entidade.Mentor.Situacao 
{ 
    public class SituacaoItem : _BaseItem 
    { 
        public string Nome { get; set; } 
    } 
} 
