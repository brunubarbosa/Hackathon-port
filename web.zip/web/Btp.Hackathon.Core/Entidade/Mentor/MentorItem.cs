using System;

namespace Btp.Hackathon.Core.Entidade.Mentor 
{ 
    public class MentorItem : _BaseItem 
    { 
        public int FuncionarioId { get; set; } 

        public int MentorSituacaoId { get; set; } 
    } 
} 
