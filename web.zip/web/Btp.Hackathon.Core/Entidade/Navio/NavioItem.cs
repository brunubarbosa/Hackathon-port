using System;

namespace Btp.Hackathon.Core.Entidade.Navio 
{ 
    public class NavioItem : _BaseItem 
    { 
        public int NavioSituacaoId { get; set; } 

        public string Nome { get; set; } 

        public int ContainerQuantidade { get; set; } 

        public DateTime DataPrevisaoChegada { get; set; } 

        public DateTime DataPrevisaoAtracacao { get; set; } 

        public DateTime DataPrevisaoDesatracacao { get; set; } 

        public DateTime DataPrevisaoSaida { get; set; } 

        public DateTime DataEfetivaChegada { get; set; } 

        public DateTime DataEfetivaAtracacao { get; set; } 

        public DateTime DataEfetivaDesatracacao { get; set; } 

        public DateTime DataEfetivaSaida { get; set; } 

        public string ArquivoFotoUrl { get; set; } 

        public string NavioSituacaoNome { get; set; }
    } 
} 
