using System;

namespace Btp.Hackathon.Core.Entidade.Cargo 
{ 
    public class CargoItem : _BaseItem 
    { 
        public string Nome { get; set; } 
    } 
} 
