using System;

namespace Btp.Hackathon.Core.Entidade.Curso.Prioridade 
{ 
    public class PrioridadeItem : _BaseItem 
    { 
        public string Nome { get; set; } 
    } 
} 
