using System;

namespace Btp.Hackathon.Core.Entidade.Curso.Modulo 
{ 
    public class ModuloItem : _BaseItem 
    { 
        public int CursoId { get; set; } 

        public int HoraQuantidade { get; set; } 

        public int PontoQuantidade { get; set; } 

        public string Titulo { get; set; } 

        public string Descricao { get; set; } 
    } 
} 
