using System;

namespace Btp.Hackathon.Core.Entidade.Curso.Modulo.Acesso 
{ 
    public class AcessoItem : _BaseItem 
    { 
        public int CursoModuloId { get; set; } 

        public int FuncionarioId { get; set; } 

        public DateTime DataInicial { get; set; } 

        public DateTime DataFinal { get; set; } 
    } 
} 
