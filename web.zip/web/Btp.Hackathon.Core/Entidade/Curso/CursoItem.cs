using System;

namespace Btp.Hackathon.Core.Entidade.Curso 
{ 
    public class CursoItem : _BaseItem 
    { 
        public int DepartamentoId { get; set; } 

        public string Nome { get; set; } 

        public string Descricao { get; set; } 
    } 
} 
