using System;

namespace Btp.Hackathon.Core.Entidade.Mentoria 
{ 
    public class MentoriaItem : _BaseItem 
    { 
        public int DepartamentoId { get; set; } 

        public int FuncionarioId { get; set; } 

        public string DepartamentoNome { get; set; }

        public string FuncionarioNome { get; set; }

        public DateTime DataInclusao { get; set; } 

        public DateTime DataValidade { get; set; } 
    } 
} 
