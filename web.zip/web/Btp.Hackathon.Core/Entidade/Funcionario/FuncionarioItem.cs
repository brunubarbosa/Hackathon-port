using System;

namespace Btp.Hackathon.Core.Entidade.Funcionario 
{ 
    public class FuncionarioItem : _BaseItem 
    { 
        public int DepartamentoId { get; set; } 

        public int CargoId { get; set; } 

        public string Codigo { get; set; } 

        public string Nome { get; set; }

        public string ArquivoFotoUrl { get; set; }

        public string DepartamentoNome { get; set; }

        public string CargoNome { get; set; }
    } 
} 
