using System.Collections.Generic;

namespace Btp.Hackathon.Core.Interface.Mentor.Situacao 
{ 
    public interface ISituacaoItem
    { 
        List<Entidade.Mentor.Situacao.SituacaoItem> CarregarLista(); 

        Entidade.Mentor.Situacao.SituacaoItem CarregarItem(int mentorSituacaoId);

        Entidade.Mentor.Situacao.SituacaoItem InserirItem(Entidade.Mentor.Situacao.SituacaoItem situacaoItem); 

        Entidade.Mentor.Situacao.SituacaoItem AtualizarItem(Entidade.Mentor.Situacao.SituacaoItem situacaoItem); 

        Entidade.Mentor.Situacao.SituacaoItem ExcluirItem(Entidade.Mentor.Situacao.SituacaoItem situacaoItem); 
    } 
} 
