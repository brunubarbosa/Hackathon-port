using System.Collections.Generic;

namespace Btp.Hackathon.Core.Interface.Mentor 
{ 
    public interface IMentorItem
    { 
        List<Entidade.Mentor.MentorItem> CarregarLista(); 

        List<Entidade.Mentor.MentorItem> CarregarListaPorFuncionarioId(int funcionarioId); 

        List<Entidade.Mentor.MentorItem> CarregarListaPorMentorSituacaoId(int mentorSituacaoId); 

        Entidade.Mentor.MentorItem CarregarItem(int mentorId);

        Entidade.Mentor.MentorItem InserirItem(Entidade.Mentor.MentorItem mentorItem); 

        Entidade.Mentor.MentorItem AtualizarItem(Entidade.Mentor.MentorItem mentorItem); 

        Entidade.Mentor.MentorItem ExcluirItem(Entidade.Mentor.MentorItem mentorItem); 
    } 
} 
