using System.Collections.Generic;

namespace Btp.Hackathon.Core.Interface.Mentor.Mentoria.Funcionario 
{ 
    public interface IFuncionarioItem
    { 
        List<Entidade.Mentor.Mentoria.Funcionario.FuncionarioItem> CarregarLista(); 

        List<Entidade.Mentor.Mentoria.Funcionario.FuncionarioItem> CarregarListaPorMentorMentoriaId(int mentorMentoriaId); 

        List<Entidade.Mentor.Mentoria.Funcionario.FuncionarioItem> CarregarListaPorFuncionarioId(int funcionarioId); 

        Entidade.Mentor.Mentoria.Funcionario.FuncionarioItem CarregarItem(int mentorMentoriaFuncionarioId);

        Entidade.Mentor.Mentoria.Funcionario.FuncionarioItem InserirItem(Entidade.Mentor.Mentoria.Funcionario.FuncionarioItem funcionarioItem); 

        Entidade.Mentor.Mentoria.Funcionario.FuncionarioItem AtualizarItem(Entidade.Mentor.Mentoria.Funcionario.FuncionarioItem funcionarioItem); 

        Entidade.Mentor.Mentoria.Funcionario.FuncionarioItem ExcluirItem(Entidade.Mentor.Mentoria.Funcionario.FuncionarioItem funcionarioItem); 
    } 
} 
