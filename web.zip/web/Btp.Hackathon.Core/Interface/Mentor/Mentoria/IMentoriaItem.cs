using System.Collections.Generic;

namespace Btp.Hackathon.Core.Interface.Mentor.Mentoria 
{ 
    public interface IMentoriaItem
    { 
        List<Entidade.Mentor.Mentoria.MentoriaItem> CarregarLista(); 

        List<Entidade.Mentor.Mentoria.MentoriaItem> CarregarListaPorMentorId(int mentorId); 

        Entidade.Mentor.Mentoria.MentoriaItem CarregarItem(int mentorMentoriaId);

        Entidade.Mentor.Mentoria.MentoriaItem InserirItem(Entidade.Mentor.Mentoria.MentoriaItem mentoriaItem); 

        Entidade.Mentor.Mentoria.MentoriaItem AtualizarItem(Entidade.Mentor.Mentoria.MentoriaItem mentoriaItem); 

        Entidade.Mentor.Mentoria.MentoriaItem ExcluirItem(Entidade.Mentor.Mentoria.MentoriaItem mentoriaItem); 
    } 
} 
