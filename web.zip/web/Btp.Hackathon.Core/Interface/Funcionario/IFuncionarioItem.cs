using System.Collections.Generic;

namespace Btp.Hackathon.Core.Interface.Funcionario 
{ 
    public interface IFuncionarioItem
    { 
        List<Entidade.Funcionario.FuncionarioItem> CarregarLista(); 

        List<Entidade.Funcionario.FuncionarioItem> CarregarListaPorDepartamentoId(int departamentoId);

        List<Entidade.Funcionario.FuncionarioItem> CarregarListaPorNavioId(int navioId);

        List<Entidade.Funcionario.FuncionarioItem> CarregarListaPorCargoId(int cargoId); 

        Entidade.Funcionario.FuncionarioItem CarregarItem(int funcionarioId);

        Entidade.Funcionario.FuncionarioItem InserirItem(Entidade.Funcionario.FuncionarioItem funcionarioItem); 

        Entidade.Funcionario.FuncionarioItem AtualizarItem(Entidade.Funcionario.FuncionarioItem funcionarioItem); 

        Entidade.Funcionario.FuncionarioItem ExcluirItem(Entidade.Funcionario.FuncionarioItem funcionarioItem); 
    } 
} 
