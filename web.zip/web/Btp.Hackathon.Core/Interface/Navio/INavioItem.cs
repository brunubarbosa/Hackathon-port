using System.Collections.Generic;

namespace Btp.Hackathon.Core.Interface.Navio 
{ 
    public interface INavioItem
    { 
        List<Entidade.Navio.NavioItem> CarregarLista(); 

        List<Entidade.Navio.NavioItem> CarregarListaPorNavioSituacaoId(int navioSituacaoId); 

        Entidade.Navio.NavioItem CarregarItem(int navioId);

        Entidade.Navio.NavioItem InserirItem(Entidade.Navio.NavioItem navioItem); 

        Entidade.Navio.NavioItem AtualizarItem(Entidade.Navio.NavioItem navioItem); 

        Entidade.Navio.NavioItem ExcluirItem(Entidade.Navio.NavioItem navioItem); 
    } 
} 
