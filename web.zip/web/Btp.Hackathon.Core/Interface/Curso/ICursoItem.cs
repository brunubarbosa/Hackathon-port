using System.Collections.Generic;

namespace Btp.Hackathon.Core.Interface.Curso 
{ 
    public interface ICursoItem
    { 
        List<Entidade.Curso.CursoItem> CarregarLista();

        List<Entidade.Curso.CursoItem> CarregarListaPorFuncionarioId(int funcionarioId);

        List<Entidade.Curso.CursoItem> CarregarListaPorDepartamentoId(int departamentoId); 

        Entidade.Curso.CursoItem CarregarItem(int cursoId);

        Entidade.Curso.CursoItem InserirItem(Entidade.Curso.CursoItem cursoItem); 

        Entidade.Curso.CursoItem AtualizarItem(Entidade.Curso.CursoItem cursoItem); 

        Entidade.Curso.CursoItem ExcluirItem(Entidade.Curso.CursoItem cursoItem); 
    } 
} 
