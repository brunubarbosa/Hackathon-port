using System.Collections.Generic;

namespace Btp.Hackathon.Core.Interface.Curso.Prioridade 
{ 
    public interface IPrioridadeItem
    { 
        List<Entidade.Curso.Prioridade.PrioridadeItem> CarregarLista(); 

        Entidade.Curso.Prioridade.PrioridadeItem CarregarItem(int cursoPrioridadeId);

        Entidade.Curso.Prioridade.PrioridadeItem InserirItem(Entidade.Curso.Prioridade.PrioridadeItem prioridadeItem); 

        Entidade.Curso.Prioridade.PrioridadeItem AtualizarItem(Entidade.Curso.Prioridade.PrioridadeItem prioridadeItem); 

        Entidade.Curso.Prioridade.PrioridadeItem ExcluirItem(Entidade.Curso.Prioridade.PrioridadeItem prioridadeItem); 
    } 
} 
