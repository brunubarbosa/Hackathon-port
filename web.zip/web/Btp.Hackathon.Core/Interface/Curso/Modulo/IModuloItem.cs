using System.Collections.Generic;

namespace Btp.Hackathon.Core.Interface.Curso.Modulo 
{ 
    public interface IModuloItem
    { 
        List<Entidade.Curso.Modulo.ModuloItem> CarregarLista(); 

        List<Entidade.Curso.Modulo.ModuloItem> CarregarListaPorCursoId(int cursoId); 

        Entidade.Curso.Modulo.ModuloItem CarregarItem(int cursoModuloId);

        Entidade.Curso.Modulo.ModuloItem InserirItem(Entidade.Curso.Modulo.ModuloItem moduloItem); 

        Entidade.Curso.Modulo.ModuloItem AtualizarItem(Entidade.Curso.Modulo.ModuloItem moduloItem); 

        Entidade.Curso.Modulo.ModuloItem ExcluirItem(Entidade.Curso.Modulo.ModuloItem moduloItem); 
    } 
} 
