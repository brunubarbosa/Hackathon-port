using System.Collections.Generic;

namespace Btp.Hackathon.Core.Interface.Curso.Modulo.Etapa 
{ 
    public interface IEtapaItem
    { 
        List<Entidade.Curso.Modulo.Etapa.EtapaItem> CarregarLista(); 

        Entidade.Curso.Modulo.Etapa.EtapaItem CarregarItem(int cursoModuloEtapaId);

        Entidade.Curso.Modulo.Etapa.EtapaItem InserirItem(Entidade.Curso.Modulo.Etapa.EtapaItem etapaItem); 

        Entidade.Curso.Modulo.Etapa.EtapaItem AtualizarItem(Entidade.Curso.Modulo.Etapa.EtapaItem etapaItem); 

        Entidade.Curso.Modulo.Etapa.EtapaItem ExcluirItem(Entidade.Curso.Modulo.Etapa.EtapaItem etapaItem); 
    } 
} 
