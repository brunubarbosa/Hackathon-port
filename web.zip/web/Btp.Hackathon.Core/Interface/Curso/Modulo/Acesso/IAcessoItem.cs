using System.Collections.Generic;

namespace Btp.Hackathon.Core.Interface.Curso.Modulo.Acesso 
{ 
    public interface IAcessoItem
    { 
        List<Entidade.Curso.Modulo.Acesso.AcessoItem> CarregarLista(); 
        
        List<Entidade.Curso.Modulo.Acesso.AcessoItem> CarregarListaPorFuncionarioId(int funcionarioId); 

        Entidade.Curso.Modulo.Acesso.AcessoItem CarregarItem(int cursoModuloAcessoId);

        Entidade.Curso.Modulo.Acesso.AcessoItem InserirItem(Entidade.Curso.Modulo.Acesso.AcessoItem acessoItem); 

        Entidade.Curso.Modulo.Acesso.AcessoItem AtualizarItem(Entidade.Curso.Modulo.Acesso.AcessoItem acessoItem); 

        Entidade.Curso.Modulo.Acesso.AcessoItem ExcluirItem(Entidade.Curso.Modulo.Acesso.AcessoItem acessoItem); 
    } 
} 
