using System.Collections.Generic;

namespace Btp.Hackathon.Core.Interface.Mentoria 
{ 
    public interface IMentoriaItem
    { 
        List<Entidade.Mentoria.MentoriaItem> CarregarLista(); 

        List<Entidade.Mentoria.MentoriaItem> CarregarListaPorDepartamentoId(int departamentoId); 

        List<Entidade.Mentoria.MentoriaItem> CarregarListaPorFuncionarioId(int funcionarioId); 

        Entidade.Mentoria.MentoriaItem CarregarItem(int mentoriaId);

        Entidade.Mentoria.MentoriaItem InserirItem(Entidade.Mentoria.MentoriaItem mentoriaItem); 

        Entidade.Mentoria.MentoriaItem AtualizarItem(Entidade.Mentoria.MentoriaItem mentoriaItem); 

        Entidade.Mentoria.MentoriaItem ExcluirItem(Entidade.Mentoria.MentoriaItem mentoriaItem); 
    } 
} 
