using System.Collections.Generic;

namespace Btp.Hackathon.Core.Interface.Cargo 
{ 
    public interface ICargoItem
    { 
        List<Entidade.Cargo.CargoItem> CarregarLista(); 

        Entidade.Cargo.CargoItem CarregarItem(int cargoId);

        Entidade.Cargo.CargoItem InserirItem(Entidade.Cargo.CargoItem cargoItem); 

        Entidade.Cargo.CargoItem AtualizarItem(Entidade.Cargo.CargoItem cargoItem); 

        Entidade.Cargo.CargoItem ExcluirItem(Entidade.Cargo.CargoItem cargoItem); 
    } 
} 
