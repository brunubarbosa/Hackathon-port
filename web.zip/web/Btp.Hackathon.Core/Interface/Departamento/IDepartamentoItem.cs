using System.Collections.Generic;

namespace Btp.Hackathon.Core.Interface.Departamento 
{ 
    public interface IDepartamentoItem
    { 
        List<Entidade.Departamento.DepartamentoItem> CarregarLista(); 

        Entidade.Departamento.DepartamentoItem CarregarItem(int departamentoId);

        Entidade.Departamento.DepartamentoItem InserirItem(Entidade.Departamento.DepartamentoItem departamentoItem); 

        Entidade.Departamento.DepartamentoItem AtualizarItem(Entidade.Departamento.DepartamentoItem departamentoItem); 

        Entidade.Departamento.DepartamentoItem ExcluirItem(Entidade.Departamento.DepartamentoItem departamentoItem); 
    } 
} 
