﻿function InicializarDataTable(dataTableId, dataTableColunaLista, dataTableConfiguracaoPersonalizada) {
    var dataTableConfiguracaoInicial = {
        'dom': '<\'html5buttons\'B>lTfgt<"row"<"col-md-6"i><"col-md-6"p>>',
        'buttons': [
            { extend: 'copy', text: 'Copiar' },
            { extend: 'csv' },
            { extend: 'excel', title: 'Exportação' },
            { extend: 'pdf', title: 'Exportação' },
            {
                extend: 'print',
                text: 'Imprimir',
                customize: function (win) {
                    $(win.document.body).addClass('white-bg');
                    $(win.document.body).css('font-size', '10px');

                    $(win.document.body).find('table')
                        .addClass('compact')
                        .css('font-size', 'inherit');
                }
            }
        ],
        'language': {
            'sEmptyTable': 'Nenhum registro encontrado',
            'sInfo': 'Mostrando de _START_ até _END_ de _TOTAL_ registros',
            'sInfoEmpty': 'Mostrando 0 até 0 de 0 registros',
            'sInfoFiltered': '(filtrados de _MAX_ registros)',
            'sInfoPostFix': '',
            'sInfoThousands': '.',
            'sLengthMenu': '_MENU_ resultados por página',
            'sLoadingRecords': 'Carregando...',
            'sProcessing': 'Processando...',
            'sZeroRecords': 'Nenhum registro encontrado',
            'sSearch': 'Pesquisar',
            'oPaginate': {
                'sNext': 'Próximo',
                'sPrevious': 'Anterior',
                'sFirst': 'Primeiro',
                'sLast': 'Último'
            },
            'oAria': {
                'sSortAscending': ': Ordenar colunas de forma ascendente',
                'sSortDescending': ': Ordenar colunas de forma descendente'
            }
        }
    };

    if (dataTableConfiguracaoPersonalizada !== null && dataTableConfiguracaoPersonalizada !== undefined) {
        $.extend(dataTableConfiguracaoInicial, dataTableConfiguracaoPersonalizada);

        dataTableConfiguracaoInicial['buttons'] = [];
    }

    if (dataTableColunaLista !== null && dataTableColunaLista !== undefined && dataTableColunaLista.length > 0)
        dataTableConfiguracaoInicial['aoColumns'] = dataTableColunaLista;

    if ($.fn.dataTable.isDataTable(dataTableId)) {
        $(dataTableId).DataTable().destroy();

        $(dataTableId + ' tbody').off('click', 'tr');
    }

    var dataTable = $(dataTableId).DataTable(dataTableConfiguracaoInicial);

    $(dataTableId + ' tbody').on('click', 'tr', function () {
        if ($(this).hasClass('selected')) {
            $(this).removeClass('selected');
        }
        else {
            $(dataTableId).DataTable().$('tr.selected').removeClass('selected');

            $(this).addClass('selected');
        }
    });

    return dataTable;
}

function AdicionarDataTableLinhaLista(dataTableId, linhaLista) {
    var dataTable = $(dataTableId).DataTable();

    dataTable
        .clear()
        .draw();

    if (linhaLista !== null && linhaLista !== undefined && linhaLista.length > 0) {
        dataTable
            .rows
            .add(linhaLista)
            .draw();
    }
}

function RenderizarDataTableDataHora(data, type, full) {
    var valor = FormatarDataWebApi(data);

    if (valor === '' || valor === null || valor === undefined)
        return null;

    return FormatarDataWebApi(data) + ' ' + FormatarHoraWebApi(data);
}

function ObterDataTableLinhaSelecionadaObjetoCss(tabelaId) {
    var table = $(tabelaId).dataTable();

    var rows = table.fnGetNodes();

    var settings = table.fnSettings();

    var valorSelecionado = 0;

    var retorno = undefined;

    $.each(rows, function (linhaIndex, linhaItem) {
        var linha = $(this);

        var selecionada = linha.hasClass('selected');

        if (selecionada) {
            retorno = settings.aoData[linhaIndex]._aData;

            return;
        }
    });

    return retorno;
}

function ObterDataTableLinhaSelecionadaListaCss(tabelaId) {
    var table = $(tabelaId).dataTable();

    var rows = table.fnGetNodes();

    var settings = table.fnSettings();

    var valorSelecionado = 0;

    var retorno = [];

    $.each(rows, function (linhaIndex, linhaItem) {
        var linha = $(this);

        var selecionada = linha.hasClass('selected');

        if (selecionada)
            retorno.push(settings.aoData[linhaIndex]._aData);
    });

    return retorno;
}

function ObterDataTableLinhaSelecionadaIndexCss(tabelaId) {
    var table = $(tabelaId).dataTable();

    var rows = table.fnGetNodes();

    var settings = table.fnSettings();

    var valorSelecionado = 0;

    var retorno = undefined;

    $.each(rows, function (linhaIndex, linhaItem) {
        var linha = $(this);

        var selecionada = linha.hasClass('selected');

        if (selecionada) {
            retorno = linhaIndex;

            return;
        }
    });

    return retorno;
}

function SelecionarDataTableLinhaLista(tabelaId, selecaoLista, campoChave) {
    var table = $(tabelaId).dataTable();

    var rows = table.fnGetNodes();

    var settings = table.fnSettings();

    $.each(rows, function (linhaIndex, linhaItem) {
        var linha = $(this);

        var jsonObjeto = settings.aoData[linhaIndex]._aData;

        $.each(selecaoLista, function (selecaoIndex, selecaoItem) {
            if (jsonObjeto[campoChave] === selecaoItem[campoChave]) {
                linha.addClass('selected');

                return;
            }
        });
    });
}