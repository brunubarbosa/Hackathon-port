﻿using Microsoft.AspNetCore.Mvc;

namespace Btp.Hackathon.WebApi.Controllers
{
    [Route("[controller]/[action]")]
    [ApiController]
    public class HomeController : _BaseController
    {
        // GET api/values
        public ActionResult Index()
        {
            return View();
        }
    }
}
