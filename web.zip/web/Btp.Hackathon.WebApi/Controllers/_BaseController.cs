﻿using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Linq;

namespace Btp.Hackathon.WebApi.Controllers
{
    public class _BaseController : Controller
    {
        protected virtual HttpResponseMessage ObterHttpResponseMessage(HttpStatusCode httpStatusCode, string jsonString)
        {
            var httpResponseMessage = new HttpResponseMessage(httpStatusCode);

            httpResponseMessage.Content = new StringContent(jsonString, Encoding.UTF8, "application/json");

            httpResponseMessage.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/json");

            httpResponseMessage.Headers.CacheControl = new System.Net.Http.Headers.CacheControlHeaderValue
            {
                NoCache = true
            };

            return httpResponseMessage;
        }

        protected virtual HttpResponseMessage ObterHttpResponseMessage(HttpStatusCode httpStatusCode, string arquivoNome, Stream Content)
        {
            var httpResponseMessage = new HttpResponseMessage(httpStatusCode);

            httpResponseMessage.Content = new StreamContent(Content);

            httpResponseMessage.Content.Headers.ContentDisposition = new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment")
            {
                FileName = arquivoNome
            };

            httpResponseMessage.Content.Headers.ContentType = new MediaTypeHeaderValue("application/octet-stream");

            return httpResponseMessage;
        }

        protected virtual HttpResponseMessage ObterHttpResponseMessage(HttpStatusCode httpStatusCode, Exception ex)
        {
            var stackTrace = new StackTrace(ex, true);

            var frame = stackTrace.GetFrame(0);

            var lineNumber = frame.GetFileLineNumber();

            var method = frame.GetMethod();

            var fileName = frame.GetFileName();

            var jsonRetorno = JsonConvert.SerializeObject(new
            {
                Message = ex.Message,
                StackTrace = ex.StackTrace,
                LineNumber = lineNumber,
                Source = ex.Source,
                TargetSite = ex.TargetSite.ReflectedType.Name + "." + ex.TargetSite.Name + "()",
                Metodo = method.Name,
                Arquivo = fileName
            });

            return ObterHttpResponseMessage(httpStatusCode, jsonRetorno);
        }

        protected virtual HttpResponseMessage ObterHttpResponseMessage(HttpStatusCode httpStatusCode, Exception ex, string jsonParametro)
        {
            var stackTrace = new StackTrace(ex, true);

            var frame = stackTrace.GetFrame(0);

            var lineNumber = frame?.GetFileLineNumber();

            var method = frame?.GetMethod();

            var fileName = frame?.GetFileName();

            var jsonRetorno = JsonConvert.SerializeObject(new
            {
                Message = ex.Message,
                StackTrace = ex.StackTrace,
                LineNumber = lineNumber,
                Source = ex.Source,
                TargetSite = ex.TargetSite?.ReflectedType.Name + "." + ex.TargetSite?.Name + "()",
                Metodo = method?.Name,
                Arquivo = fileName,
                Data = jsonParametro
            });

            return ObterHttpResponseMessage(httpStatusCode, jsonRetorno);
        }

        protected virtual T ProcessarJsonParametro<T>(JToken jToken) where T : new()
        {
            if (jToken == null)
                return default(T);

            return ProcessarJsonParametro<T>(jToken.ToString(), new IsoDateTimeConverter { DateTimeFormat = "dd/MM/yyyy" });
        }

        protected virtual T ProcessarJsonParametro<T>(string jsonParametro) where T : new()
        {
            if (string.IsNullOrEmpty(jsonParametro))
                return default(T);

            return ProcessarJsonParametro<T>(jsonParametro, new IsoDateTimeConverter { DateTimeFormat = "dd/MM/yyyy" });
        }

        protected virtual T ProcessarJsonParametro<T>(JToken jToken, IsoDateTimeConverter dateTimeConverter) where T : new()
        {
            if (jToken == null)
                return default(T);

            return ProcessarJsonParametro<T>(jToken.ToString(), dateTimeConverter);
        }

        protected virtual T ProcessarJsonParametro<T>(string jsonParametro, IsoDateTimeConverter dateTimeConverter) where T : new()
        {
            if (string.IsNullOrEmpty(jsonParametro))
                return default(T);

            return JsonConvert.DeserializeObject<T>(jsonParametro, dateTimeConverter);
        }
    }
}