﻿using Microsoft.AspNetCore.Mvc;

namespace Btp.Hackathon.WebApi.Controllers
{
    [Route("[controller]/[action]")]
    [ApiController]
    public class FuncionarioController : _BaseController
    {
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Lista()
        {
            return View();
        }
        public ActionResult Item()
        {
            return View();
        }
    }
}
