﻿using Btp.Hackathon.WebApi.Controllers;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Text.RegularExpressions;

namespace Btp.Hackathon.WebApi.Api
{
    [Route("Api/[controller]/[action]")]
    [ApiController]
    public class MentorController : _BaseController
    {
        #region Métodos Privados

        [HttpGet]
        public HttpResponseMessage CarregarMentorLista()
        {
            var mentorLista = this.ObterMentorLista();
            
            var jsonString = JsonConvert.SerializeObject(new
            {
                mentorLista
            });

            var httpResponseMessage = ObterHttpResponseMessage(HttpStatusCode.OK, jsonString);
            
            return httpResponseMessage;
        }

        [HttpGet]
        public HttpResponseMessage CarregarMentorItem(int MentorId)
        {
            var MentorItem = this.ObterMentorItem(MentorId);

            var jsonString = JsonConvert.SerializeObject(new
            {
                MentorItem
            });

            var httpResponseMessage = ObterHttpResponseMessage(HttpStatusCode.OK, jsonString);

            return httpResponseMessage;
        }

        #endregion

        #region Métodos Privados

        private List<Core.Entidade.Mentor.MentorItem> ObterMentorLista()
        {
            var MentorNegocio = new Core.Negocio.Mentor.MentorItem();

            var MentorLista = MentorNegocio.CarregarLista();

            return MentorLista;
        }

        private Core.Entidade.Mentor.MentorItem ObterMentorItem(int MentorId)
        {
            var MentorNegocio = new Core.Negocio.Mentor.MentorItem();

            var MentorItem = MentorNegocio.CarregarItem(MentorId);

            return MentorItem;
        }

        #endregion
    }
}
