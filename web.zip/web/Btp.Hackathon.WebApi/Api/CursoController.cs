﻿using Btp.Hackathon.WebApi.Controllers;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Text.RegularExpressions;

namespace Btp.Hackathon.WebApi.Api
{
    [Route("Api/[controller]/[action]")]
    [ApiController]
    public class CursoController : _BaseController
    {
        #region Métodos Privados

        [HttpGet]
        public JsonResult CarregarCursoLista()
        {
            var cursoLista = this.ObterCursoLista();

            return new JsonResult(new
            {
                cursoLista
            });
        }

        [HttpGet]
        public JsonResult CarregarCursoListaPorFuncionarioId(int funcionarioId)
        {
            var cursoLista = this.ObterCursoListaPorFuncionarioId(funcionarioId);

            return new JsonResult(new
            {
                cursoLista
            });
        }


        [HttpGet]
        public HttpResponseMessage CarregarCursoItem(int CursoId)
        {
            var CursoItem = this.ObterCursoItem(CursoId);

            var jsonString = JsonConvert.SerializeObject(new
            {
                CursoItem
            });

            var httpResponseMessage = ObterHttpResponseMessage(HttpStatusCode.OK, jsonString);

            return httpResponseMessage;
        }

        #endregion

        #region Métodos Privados

        private List<Core.Entidade.Curso.CursoItem> ObterCursoLista()
        {
            var CursoNegocio = new Core.Negocio.Curso.CursoItem();

            var CursoLista = CursoNegocio.CarregarLista();

            return CursoLista;
        }

        private List<Core.Entidade.Curso.CursoItem> ObterCursoListaPorFuncionarioId(int funcionarioId)
        {
            var CursoNegocio = new Core.Negocio.Curso.CursoItem();

            var CursoLista = CursoNegocio.CarregarListaPorFuncionarioId(funcionarioId);

            return CursoLista;
        }

        private Core.Entidade.Curso.CursoItem ObterCursoItem(int CursoId)
        {
            var CursoNegocio = new Core.Negocio.Curso.CursoItem();

            var CursoItem = CursoNegocio.CarregarItem(CursoId);

            return CursoItem;
        }

        #endregion
    }
}
