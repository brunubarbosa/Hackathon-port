﻿using Btp.Hackathon.WebApi.Controllers;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Text.RegularExpressions;

namespace Btp.Hackathon.WebApi.Api
{
    [Route("Api/[controller]/[action]")]
    [ApiController]
    public class FuncionarioController : _BaseController
    {
        #region Métodos Privados

        [HttpGet]
        public JsonResult CarregarFuncionarioLista()
        {
            var funcionarioLista = this.ObterFuncionarioLista();

            return new JsonResult(new
            {
                funcionarioLista
            });
        }

        [HttpGet]
        public JsonResult CarregarFuncionarioItem(int funcionarioId)
        {
            var funcionarioItem = this.ObterFuncionarioItem(funcionarioId);

            return new JsonResult(new
            {
                funcionarioItem
            });
        }

        [HttpGet]
        public JsonResult CarregarFuncionarioListaPorNavioId(int navioId)
        {
            var funcionarioLista = this.ObterFuncionarioListaPorNavioId(navioId);

            return new JsonResult(new
            {
                funcionarioLista
            });
        }

        #endregion

        #region Métodos Privados

        private List<Core.Entidade.Funcionario.FuncionarioItem> ObterFuncionarioLista()
        {
            var funcionarioNegocio = new Core.Negocio.Funcionario.FuncionarioItem();

            var funcionarioLista = funcionarioNegocio.CarregarLista();

            return funcionarioLista;
        }

        private Core.Entidade.Funcionario.FuncionarioItem ObterFuncionarioItem(int funcionarioId)
        {
            var funcionarioNegocio = new Core.Negocio.Funcionario.FuncionarioItem();

            var funcionarioItem = funcionarioNegocio.CarregarItem(funcionarioId);

            return funcionarioItem;
        }

        private List<Core.Entidade.Funcionario.FuncionarioItem> ObterFuncionarioListaPorNavioId(int navioId)
        {
            var funcionarioNegocio = new Core.Negocio.Funcionario.FuncionarioItem();

            var funcionarioLista = funcionarioNegocio.CarregarListaPorNavioId(navioId);

            return funcionarioLista;
        }

        #endregion
    }
}
