﻿using Btp.Hackathon.WebApi.Controllers;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Text.RegularExpressions;

namespace Btp.Hackathon.WebApi.Api
{
    [Route("Api/[controller]/[action]")]
    [ApiController]
    public class EstatisticaController : _BaseController
    {
        #region Requests

        [HttpGet]
        public HttpResponseMessage CarregarCursoCargaHorariaPorFuncionarioId(int funcionarioId)
        {
            var funcionaioItem = this.ObterFuncionarioItem(funcionarioId);

            var jsonString = JsonConvert.SerializeObject(new
            {
                
            });

            var httpResponseMessage = ObterHttpResponseMessage(HttpStatusCode.OK, jsonString);
            
            return httpResponseMessage;
        }

        #endregion

        #region Métodos Privados

        private Core.Entidade.Funcionario.FuncionarioItem ObterFuncionarioItem(int funcionarioId)
        {
            var funcionarioNegocio = new Core.Negocio.Funcionario.FuncionarioItem();

            var funcionarioItem = funcionarioNegocio.CarregarItem(funcionarioId);

            return funcionarioItem;
        }

        #endregion
    }
}
