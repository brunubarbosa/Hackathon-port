﻿using Btp.Hackathon.WebApi.Controllers;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Text.RegularExpressions;

namespace Btp.Hackathon.WebApi.Api
{
    [Route("Api/[controller]/[action]")]
    [ApiController]
    public class NavioController : _BaseController
    {
        #region Métodos Privados

        [HttpGet]
        public JsonResult CarregarNavioLista()
        {
            var navioLista = this.ObterNavioLista();

            return new JsonResult(new
            {
                navioLista
            });
        }

        [HttpGet]
        public JsonResult CarregarNavioItem(int navioId)
        {
            var navioItem = this.ObterNavioItem(navioId);

            return new JsonResult(new
            {
                navioItem
            });
        }

        #endregion

        #region Métodos Privados

        private List<Core.Entidade.Navio.NavioItem> ObterNavioLista()
        {
            var navioNegocio = new Core.Negocio.Navio.NavioItem();

            var navioLista = navioNegocio.CarregarLista();

            return navioLista;
        }

        private Core.Entidade.Navio.NavioItem ObterNavioItem(int navioId)
        {
            var navioNegocio = new Core.Negocio.Navio.NavioItem();

            var navioItem = navioNegocio.CarregarItem(navioId);

            return navioItem;
        }

        #endregion
    }
}
