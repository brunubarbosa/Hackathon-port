﻿using Btp.Hackathon.WebApi.Controllers;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Text.RegularExpressions;

namespace Btp.Hackathon.WebApi.Api
{
    [Route("Api/[controller]/[action]")]
    [ApiController]
    public class MentoriaController : _BaseController
    {
        #region Métodos Privados

        [HttpGet]
        public JsonResult CarregarMentoriaLista()
        {
            var mentoriaLista = this.ObterMentoriaLista();

            return new JsonResult(new
            {
                mentoriaLista
            });
        }

        [HttpGet]
        public JsonResult CarregarMentoriaItem(int mentoriaId)
        {
            var mentoriaItem = this.ObterMentoriaItem(mentoriaId);

            return new JsonResult(new
            {
                mentoriaItem
            });
        }

        #endregion

        #region Métodos Privados

        private List<Core.Entidade.Mentoria.MentoriaItem> ObterMentoriaLista()
        {
            var mentoriaNegocio = new Core.Negocio.Mentoria.MentoriaItem();

            var mentoriaLista = mentoriaNegocio.CarregarLista();

            return mentoriaLista;
        }

        private Core.Entidade.Mentoria.MentoriaItem ObterMentoriaItem(int mentoriaId)
        {
            var mentoriaNegocio = new Core.Negocio.Mentoria.MentoriaItem();

            var mentoriaItem = mentoriaNegocio.CarregarItem(mentoriaId);

            return mentoriaItem;
        }

        #endregion
    }
}
