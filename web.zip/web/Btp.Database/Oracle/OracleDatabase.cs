﻿using System.Data;

namespace Btp.Database.Oracle
{
    public class OracleDatabase : Base._BaseItem, Interface.IDatabase
    {
        private static string connectionStringOracleKey = "ConnectionString.Oracle";
        
        public OracleDatabase()
            : this(System.Configuration.ConfigurationManager.AppSettings[connectionStringOracleKey].ToString())
        { }

        public OracleDatabase(string connectionString)
        {
            this._connectionString = connectionString;
        }

        public DataSet ExecutarRetornandoDataSet(string sql)
        {
            throw new System.NotImplementedException();
        }

        public DataTable ExecutarRetornandoDataTable(string sql)
        {
            throw new System.NotImplementedException();
        }

        public void ExecutarSemRetorno(string sql)
        {
            throw new System.NotImplementedException();
        }
    }
}
