﻿using Btp.Database.Interface;
using System;
using System.Linq;
using System.Collections.Generic;

namespace Btp.Database.Base
{
    public enum DATABASE_TIPO_ID
    {
        MSSQL = 1,
        ORACLE = 2,
        MYSQL = 3
    }

    public class _BaseItem
    {
        public static DATABASE_TIPO_ID DatabaseTipoId
        {
            get
            {
                var databaseTipoId = DATABASE_TIPO_ID.MSSQL; //(DATABASE_TIPO_ID)Enum.Parse(typeof(DATABASE_TIPO_ID), System.Configuration.ConfigurationManager.AppSettings["Database.Tipo.Id"]?.ToString());

                return databaseTipoId;
            }
        }

        public static string DatabaseUrl
        {
            get
            {
                var databaseUrl = "DESKTOP-B5E16NR\\SQLEXPRESS"; //System.Configuration.ConfigurationManager.AppSettings["Database.Url"]?.ToString();

                return databaseUrl;
            }
        }

        public static string DatabaseNome
        {
            get
            {
                var databaseNome = "BTP_DB"; //System.Configuration.ConfigurationManager.AppSettings["Database.Nome"]?.ToString();

                return databaseNome;
            }
        }

        public static string DatabaseUsuario
        {
            get
            {
                var databaseUsuario = "sa"; //System.Configuration.ConfigurationManager.AppSettings["Database.Usuario"]?.ToString();

                return databaseUsuario;
            }
        }

        public static string DatabaseSenha
        {
            get
            {
                var databaseSenha = "cranio22"; //System.Configuration.ConfigurationManager.AppSettings["Database.Senha"]?.ToString();

                return databaseSenha;
            }
        }

        protected string _connectionString { get; set; }

        public virtual string ObterQueryString(DATABASE_TIPO_ID databaseTipoId)
        {
            var connectionString = string.Empty;

            switch (databaseTipoId)
            {
                case DATABASE_TIPO_ID.MSSQL:
                    connectionString = string.Format("Server={0};Initial Catalog={1};User Id={2};Password={3};Integrated Security=False;MultipleActiveResultSets=True;", _BaseItem.DatabaseUrl, _BaseItem.DatabaseNome, _BaseItem.DatabaseUsuario, _BaseItem.DatabaseSenha);
                    break;

                case DATABASE_TIPO_ID.ORACLE:
                    break;

                case DATABASE_TIPO_ID.MYSQL:
                    connectionString = string.Format("Server={0};Port=3306;Database={1};Uid={2};Pwd={3};SslMode=none;", _BaseItem.DatabaseUrl, _BaseItem.DatabaseNome, _BaseItem.DatabaseUsuario, _BaseItem.DatabaseSenha);
                    break;
            }

            return connectionString;
        }

        public List<T> ParseDataTable<T>(System.Data.DataTable dataTable, Dictionary<string, string> dicionario) where T : new()
        {
            var lista = new List<T>();

            if (dataTable != null)
                foreach (var dataRow in dataTable.Rows)
                {
                    var item = this.ParseDataRow<T>((System.Data.DataRow)dataRow, dicionario);

                    lista.Add(item);
                }

            return lista;
        }

        public T ParseDataRow<T>(System.Data.DataRow dataRow, Dictionary<string, string> dicionario) where T : new()
        {
            var entidade = new T();

            if (dicionario == null)
                dicionario = new Dictionary<string, string>();

            var propriedadeLista = entidade.GetType().GetProperties();

            foreach (var propriedadeItem in propriedadeLista)
            {
                var dicionarioItem = dicionario
                    .Where(x => x.Key.Equals(propriedadeItem.Name))
                    .FirstOrDefault();

                if (propriedadeItem != null && propriedadeItem.CanWrite)
                {
                    var propriedadeNome = string.Empty;

                    if (dicionarioItem.Value == null)
                        propriedadeNome = propriedadeItem.Name;
                    else
                        propriedadeNome = dicionarioItem.Value;

                    if (!dataRow.Table.Columns.Contains(propriedadeNome))
                        continue;

                    if (dataRow.IsNull(propriedadeNome) && !propriedadeItem.PropertyType.Name.Equals("String"))
                        continue;

                    var propriedadeValor = Convert.ChangeType(dataRow[propriedadeNome], propriedadeItem.PropertyType);

                    if (propriedadeItem.PropertyType.Name.Equals("String") && string.IsNullOrEmpty((string)propriedadeValor))
                        propriedadeValor = string.Empty;

                    propriedadeItem.SetValue(entidade, propriedadeValor, null);
                }
            }

            return entidade;
        }

        public List<T> CarregarLista<T>(IDatabase database, string sql, Dictionary<string, string> dicionario) where T : new()
        {
            var dataTable = database.ExecutarRetornandoDataTable(sql);

            return this.ParseDataTable<T>(dataTable, dicionario);
        }

        public T CarregarItem<T>(IDatabase database, string sql, Dictionary<string, string> dicionario) where T : new()
        {
            var dataTable = database.ExecutarRetornandoDataTable(sql);

            var lista = this.ParseDataTable<T>(dataTable, dicionario);

            return lista.FirstOrDefault();
        }
    }
}
